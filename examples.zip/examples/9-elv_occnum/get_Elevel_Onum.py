# author: Hanbin He
# 2023.11.17
# Written for calculating energy levels and electron occupation numbers.

import numpy as np
import glob
import math

file_name_p = input("--> The file containing the dos data: ")
file_path = glob.glob(file_name_p)
#--------------------------------------------------------------------------------------------------------------------------#
Num_file = open(file_path[0],'r+')  #file_path是个列表，列表里边的第0个就是含PDOS的文件名，这里不要改
Num_lines = Num_file.readline()  
num_lines = Num_lines.split()
numlines = len(num_lines)
dos_num = numlines -1     #计算DOS的个数,但是截取列的时候得+1。
#--------------------------------------------------------------------------------------------------------------------------#
ene = np.loadtxt(file_path[0],skiprows=0,usecols=0,dtype=np.float64)
dos = np.loadtxt(file_path[0],skiprows=0,usecols=(range(1, numlines)),dtype=np.float64)  #加了个判断，可判断有几个轨道
de  = ene[1] - ene[0]

ene_lvs  = []
occ_nums = []

for i in range(0,dos.shape[1]):
    ene_lvs.append(np.einsum('i,i->',dos[:,i],ene*de))
    occ_nums.append(np.einsum('i->',dos[:,i]*de))

eta = np.divide(ene_lvs , occ_nums)

ene_F = [i for i in ene if i < 0]
iFermi = len(ene_F)
dos_F = dos[0:iFermi]


occ_nums_F = []

for i in range(0,dos.shape[1]):
    occ_nums_F.append(np.einsum('i->',dos_F[:,i]*de))
#print(occ_nums_F)

occ_nums_F1 = []   #此处加个绝对值，因为占据数应该为正数
for i in occ_nums_F:
    occ_nums_F1.append(math.fabs(i))
#print(occ_nums_F1)

#title = np.loadtxt(file_path[0])[0] #用这个方法会出现被“#”注释的行无法读取

file = open(file_path[0],'r+')  #file_path是个列表，列表里边的第0个就是含PDOS的文件名，这里不要改
lines = file.readline()  
title = lines.split()

print("--> Output: Elv_OccN_results.dat")

with open('Elv_OccN_results.dat','w') as r:  
    r.write('%8s %12s %8s\n'%('#Orbital','Energy LV', 'Occ Num'))
    for ii,i in enumerate(eta):
        r.write('%s %10.6f %10.6f\n'%(title[ii+1], eta[ii], occ_nums_F1[ii]))  #未修改之前此处为occ_nums_F[ii]

with open('Elv_OccN_results.dat', 'r') as rfile:
    rescontent = rfile.read()
    print(rescontent)
#Energy Levels and Electron Occupation Numbers



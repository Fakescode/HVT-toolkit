#/bin/bash
i=`grep -n " 108" CHGCAR | awk -F ':' '{print $1}' | head -n 1`
j=`grep -n " 108" CHGCAR | awk -F ':' '{print $1}' | tail -n 1`
j=$[$j -1]
sed '$i,${j}d' CHGCAR > SPIN.VASP

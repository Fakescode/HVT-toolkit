# author: Hanbin He
# 2023.11.17
# Written for plot energy levels and electron occupation numbers.
# Use get_Elevel_Onum.py first. 

import numpy as np
import glob
import math
import matplotlib.pyplot as plt

def redb_bluet():
    plt.annotate('%.2f'%UPO[i], xy = (new_orb[i], UPE[i]),verticalalignment='bottom',xytext = (new_orb[i], UPE[i]-pianyi),horizontalalignment='center',fontsize=13,color='red')
    plt.annotate('%.2f'%DWO[i], xy = (new_orb[i], DWE[i]),verticalalignment='top',xytext = (new_orb[i], DWE[i]+pianyi),horizontalalignment='center',fontsize=13,color='blue')

def redt_blueb():
    plt.annotate('%.2f'%UPO[i], xy = (new_orb[i], UPE[i]),verticalalignment='top',xytext = (new_orb[i], UPE[i]+pianyi),horizontalalignment='center',fontsize=13,color='red')
    plt.annotate('%.2f'%DWO[i], xy = (new_orb[i], DWE[i]),verticalalignment='bottom',xytext = (new_orb[i], DWE[i]-pianyi),horizontalalignment='center',fontsize=13,color='blue')

file_path = glob.glob('Elv_OccN_results.dat') 

orbita = np.loadtxt(file_path[0],skiprows=0,usecols=0,dtype=str)
EL = np.loadtxt(file_path[0],skiprows=0,usecols=(1),dtype=np.float64)
ON = np.loadtxt(file_path[0],skiprows=0,usecols=(2),dtype=np.float64)

#加个判断：最大最小值判断，由此设定画图范围
elmax = max(EL)
elmin = min(EL)
y_range = (elmax - elmin) / 5      #这个除数（5）是个自定义值，可以改（4，3，2）
#print(elmax,elmin)
Ymax = elmax + y_range
Ymin = elmin - y_range
#print(Ymax,Ymin,y_range)
pianyi = (Ymax - Ymin) / 18        #用来判断标注的电子占据数的数字在横线上下的位置偏移量
judge_1 = (Ymax - Ymin) / 10       #判据：判断是否需要将表述的电子占据数反调
#print(judge_1)                    #检查判据的值

orbita1 = []
for i in orbita:
    i = i.split('_')[-1]
    orbita1.append(i)    #整理出了每行数据对应的轨道

new_orb=[]
for j in orbita1:
    if j not in new_orb:
        new_orb.append(j)       #将轨道进行的去重   # 1.这里需要加个判断，如果读到dx2，则设置为d_x2-y2

new_orbi=[]
for k in new_orb:
    if k == "dx2":
        new_orbi.append("dx2-y2")
    else:
        new_orbi.append(k)      #尝试解决问题1，但是会导致d_x2-y2的标注跑偏很远

UPE = []
DWE = []
UPE = EL[::2]    #取列表EL中的奇数位元素
DWE = EL[1::2]   #取列表EL中的偶数位元素

UPO = []
DWO = []
UPO = ON[::2]    #取列表ON中的奇数位元素
DWO = ON[1::2]   #取列表ON中的偶数位元素

num = len(new_orb) #判断x轴刻度值个数
plt.xlim(-1,num)  #这个地方需要利用上个判断
plt.ylim(Ymin,Ymax)

plt.scatter(new_orb,UPE,marker='_',s=800,color='red',label='up')
plt.scatter(new_orb,DWE,marker='_',s=800,color='blue',label='down')

#这里有个判断，让画图的时候电子占据数自己判断处于横线上方还是下方,判断方法用最大最小值即max()和min()函数。

for i in range(len(UPE)):  #UPE,DWE是两个列表,ok，非常好，判断就这么写,大于小于的情况要多加一个判断
    if '%.2f'%UPE[i] == '%.2f'%DWE[i]:      #懂了，这里要有个判断，upe>dwe时,如果二者都为负，则dwe-upe；如果upe为正，则upe-dwe；排列组合一下就知道了
        redb_bluet()
    else:
        judge_2 = max(UPE[i],DWE[i])  #判断两个自旋朝向的能级哪个大
        #print(UPE[i],DWE[i],judge_2)  #检查判据没问题
        if judge_2 == UPE[i]:
            #print("upe>dwe") #判断用
            canzhao = float('%.2f'%UPE[i]) - float('%.2f'%DWE[i])
            if canzhao > judge_1:
                redb_bluet()
            else:
                redt_blueb()
        elif judge_2 == DWE[i]:
            #print("dwe>upe")  #判断用
            canzhao = float('%.2f'%DWE[i]) - float('%.2f'%UPE[i])
            if canzhao > judge_1:
                redt_blueb()
            else:
                redb_bluet()
        else:
            print("Error,please check!")

print("--> Finish")

plt.gcf().subplots_adjust(left=0.2) #左边可能出现ylabel在图外的情况，这个默认是1，调成2即可
plt.ylabel("Energy (eV)",fontsize=14)  #设置ylabel
plt.tick_params(labelsize=14)   #刻度值字体大小
plt.legend()
plt.legend(frameon=False) #去掉图例边框
plt.savefig('Elevel_Onum.png')



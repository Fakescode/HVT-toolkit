#!/bin/bash
#Hanbin_He
head -9 $1 > POSCAR-out
#awk '{if (NR<10) print $0}' $1 > POSCAR-out #More advanced languages,Can also be used, as an alternative.
grep -v "0000E+00" $1 >> pos
#sed -n '10,$p' pos >> POSCAR-out
cat pos | sed -n '10,$p' | awk '{ print $1"  "$2"  "$3 }' >> POSCAR-out
rm -rf pos
sed -i '8d' POSCAR-out #delect the line of 'Selective dynamics'
mv $1 $1-FT

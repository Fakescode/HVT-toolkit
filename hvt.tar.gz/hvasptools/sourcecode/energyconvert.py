#!/usr/bin/env python
# -*- coding: utf-8 -*-
# To use it: python energyconverter.py
# version : 1.0
import os
import math
# 这是我最无聊的时候写的脚本，超级无聊
# 1 Hartrees = 27.211399 eV = 2625.5002 kJ/mol = 627.5096080305927 kcal/mol
# 1 eV = 0.03674930495120813 Hartrees = 96.48530749925793 kJ/mol = 23.060541945329334 kcal/mol
# 1 kJ/mol = 0.0003808798033989866 Hartrees = 0.01036427230133138 eV = 0.2390057361376673 kcal/mol
# 1 kcal/mol = 0.0015936010974213599 Hartrees = 0.0433641153087705 eV = 4.184 kJ/mol
# 1 a.u. = 1 Hartree #原子单位（a.u.）-能量
#-------------------------------------------------------------------------------------------------#
print("""+---------------------------------------------------+
|           Energy Units Converter Script           |""")
print("""+---------------------------------------------------+
| Examples: 1 eV, 1 Hartree, 1 kJ/mol, 1 kcal/mol   |
| Separate energy values and units with a space " " |
+---------------------------------------------------+""")
E,unit = input('Please enter the energy you wish to convert: ').split(' ')  
Energy = float(E)
units = str(unit) 
if ( units == "Hartree" ) or ( units == "Hartrees" ) or ( units == "hartrees" ) or ( units == "hartree" ):
    E_eV = Energy * 27.211399
    E_kJ = Energy * 2625.5002
    E_kcal = Energy * 627.5096080305927
    print("Results:  %.6f Hartrees  %.6f eV  %.6f kJ/mol  %.6f kcal/mol" %(Energy,E_eV,E_kJ,E_kcal))
elif ( units == "eV" ) or ( units == "ev" ) or ( units == "EV" ):
    E_har = Energy * 0.03674930495120813
    E_kJ = Energy * 96.48530749925793
    E_kcal = Energy * 23.060541945329334
    print("Results:  %.6f Hartrees  %.6f eV  %.6f kJ/mol  %.6f kcal/mol" %(E_har,Energy,E_kJ,E_kcal))
elif ( units == "kj/mol" ) or ( units == "kJ/mol" ) or ( units == "KJ/mol" ) or ( units == "Kj/mol" ):
    E_har = Energy * 0.0003808798033989866
    E_eV = Energy * 0.01036427230133138
    E_kcal = Energy * 0.2390057361376673
    print("Results:  %.6f Hartrees  %.6f eV  %.6f kJ/mol  %.6f kcal/mol" %(E_har,E_eV,Energy,E_kcal))
elif ( units == "kcal/mol" ) or ( units == "Kcal/mol" ) or ( units == "KCAL/mol" ):
    E_har = Energy * 0.0015936010974213599
    E_eV = Energy * 0.0433641153087705
    E_kJ = Energy * 4.184
    print("Results:  %.6f Hartrees  %.6f eV  %.6f kJ/mol  %.6f kcal/mol" %(E_har,E_eV,E_kJ,Energy))
elif ( units == "j/mol" ) or ( units == "J/mol" ):
    E_kJ = Energy / 1000
    E_har = E_kJ * 0.0003808798033989866
    E_eV = E_kJ * 0.01036427230133138
    E_kcal = E_kJ * 0.2390057361376673
    print("Results:  %.6f Hartrees  %.6f eV  %.6f kJ/mol  %.6f kcal/mol" %(E_har,E_eV,E_kJ,E_kcal))
elif ( units == "cal/mol" ) or ( units == "Cal/mol" ) or ( units == "CAL/mol" ):
    E_kcal = Energy / 1000
    E_har = E_kcal * 0.0015936010974213599
    E_eV = E_kcal * 0.0433641153087705
    E_kJ = E_kcal * 4.184
    print("Results:  %.6f Hartrees  %.6f eV  %.6f kJ/mol  %.6f kcal/mol" %(E_har,E_eV,E_kJ,E_kcal))
else:
    print("The unit",units,"is not included in this script.")



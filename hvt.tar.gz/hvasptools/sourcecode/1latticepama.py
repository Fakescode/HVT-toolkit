import math
import numpy as np
filen = input("""--> Select file: 1. POSCAR; 2. CONTCAR -> """)
if ( filen == "1" ):
    file = "POSCAR"
elif ( filen == "2" ):
    file = "CONTCAR"
else:
    print("--> Error input, select default: POSCAR.")
    file = "POSCAR"


with open(file) as f:
    lattice = f.readlines()[2:5]
    A = lattice[0]
    B = lattice[1]
    C = lattice[2] #突然很无聊，写堆屎玩玩
    a1a2a3 = A.split()
    a1 = a1a2a3[0]
    a2 = a1a2a3[1]
    a3 = a1a2a3[2]
    a1 = float(a1)
    a2 = float(a2)
    a3 = float(a3)
    b1b2b3 = B.split()
    b1 = b1b2b3[0]
    b2 = b1b2b3[1]
    b3 = b1b2b3[2]
    b1 = float(b1)
    b2 = float(b2)
    b3 = float(b3)
    c1c2c3 = C.split()
    c1 = c1c2c3[0]
    c2 = c1c2c3[1]
    c3 = c1c2c3[2]
    c1 = float(c1)
    c2 = float(c2)
    c3 = float(c3)
    ab1 = (a1 * b1) + (a2 * b2) + (a3 * b3)
    ac1 = (a1 * c1) + (a2 * c2) + (a3 * c3)
    cb1 = (c1 * b1) + (c2 * b2) + (c3 * b3) #后边求角度用
    An1 = math.sqrt( math.pow(a1,2) + math.pow(a2,2) + math.pow(a3,2) )
    Bn2 = math.sqrt( math.pow(b1,2) + math.pow(b2,2) + math.pow(b3,2) )
    Cn3 = math.sqrt( math.pow(c1,2) + math.pow(c2,2) + math.pow(c3,2) ) #晶格常数
    n1 = ( 2 * math.pi) / (math.sqrt( math.pow(a1,2) + math.pow(a2,2) + math.pow(a3,2) ) )
    n2 = ( 2 * math.pi) / (math.sqrt( math.pow(b1,2) + math.pow(b2,2) + math.pow(b3,2) ) )
    n3 = ( 2 * math.pi) / (math.sqrt( math.pow(c1,2) + math.pow(c2,2) + math.pow(c3,2) ) )  #倒格子常数
    gamma = math.acos( ab1 / ( An1 * Bn2 ) )
    gamma =  math.degrees(gamma)
    alpha = math.acos( cb1 / ( Cn3 * Bn2 ) )
    alpha =  math.degrees(alpha)
    beta = math.acos( ac1 / ( An1 * Cn3 ) )
    beta =  math.degrees(beta)
    print("--> Lattice parameters :")
    print("    a = %.5f , b = %.5f , c = %.5f "%(An1,Bn2,Cn3))
    print("    alpha = %.5f , beta = %.5f , gamma = %.5f"%(alpha,beta,gamma))



#!/usr/bin/env python
# -*- coding: utf-8 -*-
# version:1.0
# author: Hanbin
# Used to scientifically generate kpoints. 
import math
import numpy as np
print("--> K-Mesh Scheme")
kstyle = input("""--> Please make your selection: 1. Monkhorst-Pack Scheme; 2. Gamma Scheme -> """)
if ( kstyle == "1" ):
    print("--> Monkhorst-Pack Scheme.")
    stylek = "Monkhorst-Pack"
elif ( kstyle == "2" ):
    print("--> Gamma Scheme.")
    stylek = "Gamma"
else:
    print("--> Error input, Set to default: Gamma Scheme.")
    stylek = "Gamma"
with open("POSCAR") as f:
    lattice = f.readlines()[2:5]
    A = lattice[0]
    B = lattice[1]
    C = lattice[2] #突然很无聊，写堆屎玩玩
    a1a2a3 = A.split()
    a1 = a1a2a3[0]
    a2 = a1a2a3[1]
    a3 = a1a2a3[2]
    a1 = float(a1)
    a2 = float(a2)
    a3 = float(a3)
    b1b2b3 = B.split()
    b1 = b1b2b3[0]
    b2 = b1b2b3[1]
    b3 = b1b2b3[2]
    b1 = float(b1)
    b2 = float(b2)
    b3 = float(b3)
    c1c2c3 = C.split()
    c1 = c1c2c3[0]
    c2 = c1c2c3[1]
    c3 = c1c2c3[2]
    c1 = float(c1)
    c2 = float(c2)
    c3 = float(c3)
    ab1 = (a1 * b1) + (a2 * b2) + (a3 * b3)
    ac1 = (a1 * c1) + (a2 * c2) + (a3 * c3)
    cb1 = (c1 * b1) + (c2 * b2) + (c3 * b3) #后边求角度用
    An1 = math.sqrt( math.pow(a1,2) + math.pow(a2,2) + math.pow(a3,2) )
    Bn2 = math.sqrt( math.pow(b1,2) + math.pow(b2,2) + math.pow(b3,2) )
    Cn3 = math.sqrt( math.pow(c1,2) + math.pow(c2,2) + math.pow(c3,2) ) #晶格常数
    n1 = ( 2 * math.pi) / (math.sqrt( math.pow(a1,2) + math.pow(a2,2) + math.pow(a3,2) ) )
    n2 = ( 2 * math.pi) / (math.sqrt( math.pow(b1,2) + math.pow(b2,2) + math.pow(b3,2) ) )
    n3 = ( 2 * math.pi) / (math.sqrt( math.pow(c1,2) + math.pow(c2,2) + math.pow(c3,2) ) )  #倒格子常数
    gamma = math.acos( ab1 / ( An1 * Bn2 ) )
    gamma =  math.degrees(gamma)
    alpha = math.acos( cb1 / ( Cn3 * Bn2 ) )
    alpha =  math.degrees(alpha)
    beta = math.acos( ac1 / ( An1 * Cn3 ) )
    beta =  math.degrees(beta)
    print("--> Lattice parameters :")
    print("    a = %.5f , b = %.5f , c = %.5f "%(An1,Bn2,Cn3))
    print("    alpha = %.5f , beta = %.5f , gamma = %.5f"%(alpha,beta,gamma))
    dbz = input("""--> Input Kmesh-Resolved Value (in Units of 2*PI/Angstrom) (reference : 0.03-0.04) -> """)  #The density of Brillouin zone
    #留个bug，这里当输入的值过大的时候可能会出现输出k点为 0 0 0 的情况，但是只要根据提示输就不会有问题。
    dbz = float(dbz)
    epaidbz = ( 2 * math.pi ) * dbz
    k1 = n1 / epaidbz  #KPOINTS
    k2 = n2 / epaidbz  
    k3 = n3 / epaidbz 
    print("--> The k-mesh was calculated as: %.f %.f %.f"%(k1,k2,k3)) #输出根据布里渊区密度计算得到的推荐K点值
with open("POSCAR") as f:
        fttype = f.readlines()[7] #这个在固定座标的时候需要读第八行
        typeFT = fttype[0]
        if (typeFT=="S") :
            FTs = "y"
        elif (typeFT=="C") or (typeFT=="D") or (typeFT=="s") or (typeFT=="d"):
            FTs = "n"
        else:
            print("--> ERROR setting of POSCAR.") 
l1 = []
l2 = []
l3 = [] 
with open("POSCAR") as f:
    if (FTs == "y"):
        datas = f.readlines()[9:-1]  #这个在固定坐标的时候需要[9:-1]，也就是读第10行到最后一行
    elif (FTs == "n"):
        datas = f.readlines()[8:-1]
    else:
        print("--> ERROR")
    for da in datas:
        dataa = da.split()
        da1 = dataa[0]
        da1 = float(da1) #! 
        l1.append(da1) 
        da2 = dataa[1]
        da2 = float(da2)
        l2.append(da2)   
        da3 = dataa[2]
        da3 = float(da3)
        l3.append(da3)   
    float_l3 = list(np.float_(l3))
    xmax = max(l1)
    ymax = max(l2)
    zmax = max(l3)
    xmin = min(l1)
    ymin = min(l2)
    zmin = min(l3)
    xmax = float(xmax)
    ymax = float(ymax)
    zmax = float(zmax)
    xmin = float(xmin)
    ymin = float(ymin)
    zmin = float(zmin)
    xsuml = xmax - xmin
    ysuml = ymax - ymin
    zsuml = zmax - zmin 
KPOINT = []
with open("POSCAR") as f:
    if (FTs == "y"):
        postype = f.readlines()[8] #这个在固定座标的时候需要读第9行,也就是[8]
        type = postype[0]
    elif (FTs == "n"):
        postype = f.readlines()[7] #这个在固定座标的时候需要读第9行,也就是[8]
        type = postype[0]
    else:
        print("--> ERROR")
if ( type=="D" ) or ( type=="d" ):    #direct mode
    #print('--> POSCAR in Direct coordinates');
    if xsuml > 0.8:   
        k1 = '%.f'%k1
        KPOINT.append(k1)
    else:           
        KPOINT.append(1)
    if ysuml > 0.8:    #direct mode
        k2 = '%.f'%k2
        KPOINT.append(k2)
    else:           
        KPOINT.append(1)
    if zsuml > 0.8:    #direct mode
        k3 = '%.f'%k3
        KPOINT.append(k3)
    else:            
        KPOINT.append(1)
elif ( type=="C" ) or ( type=="c" ):  #cartesian mode
    #print("--> POSCAR in Cartesian coordinates")
    xaxis = xsuml / An1
    yaxis = ysuml / Bn2
    zaxis = zsuml / Cn3
    xaxis = float(xaxis)
    yaxis = float(yaxis)
    zaxis = float(zaxis)
    if xaxis > 0.75:    #cartesian mode
        k1 = '%.f'%k1
        KPOINT.append(k1)
    else:            
        KPOINT.append(1)
    if yaxis > 0.75:    #cartesian mode
        k2 = '%.f'%k2
        KPOINT.append(k2)
    else:           
        KPOINT.append(1)
    if zaxis > 0.75:    #cartesian mode
        k3 = '%.f'%k3
        KPOINT.append(k3)
    else:         
        KPOINT.append(1)
#cartesian坐标下的标准设置的比direct的低,因为测试样本的缘故
else:           
        print('--> ERROR Coordinates');
        f=open("KPOINTS-111","w")
        f.write(('KPOINTS-Auto\n0\nMonkhorst-Pack\n   1   1   1 \n0.0  0.0  0.0\n'))
        f.close()
        print("--> Please refer to the reference case to set the relevant parameters.")
kkk1 = str(KPOINT[0])
kkk2 = str(KPOINT[1])
kkk3 = str(KPOINT[2])
print("--> KPOINTS was created with k-kmesh: %s %s %s due to the material."%(KPOINT[0],KPOINT[1],KPOINT[2]))
f=open("KPOINTS","w")
f.write(('KPOINTS-Auto\n0\n%s\n   %s   %s   %s \n0.0  0.0  0.0\n')%(stylek,KPOINT[0],KPOINT[1],KPOINT[2]))
f.close()
#print("--> The dimension of material may be wrong and you could revise it manually.")


#----------------------------------------------#
#| 写的这么烂，改的时候一定很麻烦，建议不要改     |#
#| POSCAR的格式建议用vesta产生，如下:           |#
#| NiO                                        |#
#| 4.03500000                                 |#
#| 2.0000000000   1.0000000000   1.0000000000 |#
#| 1.0000000000   2.0000000000   1.0000000000 |#
#| 1.0000000000   1.0000000000   2.0000000000 |#
#| Ni O     !这行必须得有                      |#
#| 16 16                                      |#
#| 0.0000000000   0.0000000000   0.0000000000 |#
#| 0.2500000000   0.2500000000   0.2500000000 |#
#| 0.0000000000   0.0000000000   0.5000000000 |#
#| 0.2500000000   0.2500000000   0.7500000000 |#
#| 0.0000000000   0.5000000000   0.5000000000 |#
#| 此处略去好多行...                           |#
#----------------------------------------------#

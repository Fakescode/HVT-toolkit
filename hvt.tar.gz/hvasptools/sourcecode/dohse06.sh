#!/bin/bash
#script to help do hse06 band
#Hanbin_He
echo -e "\e[33m                +------------------------+\e[0m"
echo -e "\e[33m                |    HSE06 band script   |\e[0m"
echo -e "\e[33m                +------------------------+\e[0m"
echo -e "\e[33m--------------------------------------------------------------\e[0m"
echo -e "\e[37m  Firstly,creat a file to do pbescf...  \e[0m"
echo -e "\e[37m  Next,creat a file to do hse06 band cal   \e[0m"
echo -e "\e[37m  Finally, modify INCAR and perform pbe-scf calculation. \e[0m"
echo -e "\e[37m  Once you've done scf, move WAVECAR and CHGCAR to hse06band\e[0m"
echo -e "\e[33m--------------------------------------------------------------\e[0m"
mkdir pbescf
cp POTCAR CONTCAR pbescf
cd pbescf
mv CONTCAR POSCAR
echo -e "302" | vaspkit >> gkpath.dat
echo -e "251\n2\n0.03\n0.03" | vaspkit >> gkpoints.dat
#echo -e "SYSTEM = pbescf\nISTART = 0\nISPIN=2\nISIF=2 \nLREAL=.T.\nENCUT = 500.00 eV\nISMEAR = 0\nSIGMA=0.05\nIVDW=12\nLDIPOL=.T.\nEDIFF = 1E-06\nIBRION = -1\nNSW = 0\nPREC=Accurate\nEDIFFG=-0.02\nPOTIM=0.2\nNPAR=4\nIDIPOL=3" > INCAR.ref
cp /home/hanbin/scripts/callfile/INCAR-hse06/INCAR-pbescf .
rm -rf INCAR
mkdir hse06band
cp POSCAR POTCAR hse06band
cp KPATH.in  KPOINTS hse06band
cd hse06band
echo "need CHGCAR WAVECAR" > need_CHGCAR_WAVECAR
#echo -e "SYSTEM = HSE06_band\nISTART = 1\nISPIN=2\nISIF=2 \nLREAL=.T.\nENCUT = 500.00 eV\nISMEAR = 0\nSIGMA=0.05\nIVDW=12\nLDIPOL=.T.\nEDIFF = 1E-06\nIBRION = -1\nNSW = 0\nPREC=Accurate\nEDIFFG=-0.01\nPOTIM=0.2\nNPAR=4\nIDIPOL=3\nICHARG = 1\nLORBIT = 11\nLWAVE = .FALSE.\nLCHARG = .FALSE.\nLHFCALC = .TRUE.\nHFSCREEN = 0.2\nALGO = Damped\nTIME = 0.4\nAEXX = 0.25" > INCAR.ref
cp /home/hanbin/scripts/callfile/INCAR-hse06/INCAR-hse06 .
cd ..
cd ..
echo -e "\e[33mThe files are ready before calculation. Please calculate after checking.\e[0m"

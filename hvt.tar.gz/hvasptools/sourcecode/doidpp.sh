#!/bin/bash
echo "--> Generate images for ci-neb with idpp method"
read -p "--> ini structure = " AB
read -p "--> fin structure = " A
read -p "--> Num of images = " B

python idpp-pymatgen.py $AB $A $B


#!/bin/bash
#author: Hanbin_He
#To get the Thermal Corrections calculate by Gaussian.(freq/opt+freq)
#To use it: bash ***.sh **.log
#-------------------------------------------------------------------------------------#
# Zero-point correction=  ZPE                         
# Thermal correction to Energy=  ZPE + deltaU[0->T]                 
# Thermal correction to Enthalpy=  ZPE + deltaH[0->T]               
# Thermal correction to Gibbs Free Energy=  ZPE + deltaG[0->T]      
# Sum of electronic and zero-point Energies=  U(0) = E_DFT + ZPE    
# Sum of electronic and thermal Energies=  U(T) = E_DFT + ZPE + deltaU[0->T]         
# Sum of electronic and thermal Enthalpies=  H(T) =  E_DFT + ZPE + deltaH[0->T]    
# Sum of electronic and thermal Free Energies=  G(T) = E_DFT + ZPE + deltaG[0->T]     
# 1 Hartees = 27.211396641308 eV
#-------------------------------------------------------------------------------------#
file=$1
hartees=27.211396641308
#sta=$(grep -n "Zero-point correction=" $file | awk '{print $1}' |tail -1|tr -d ':')
#echo "sta = $sta"
#sto=$(grep -n "Sum of electronic and thermal Free Energies=" $file | awk '{print $1}' |tail -1|tr -d ':' )
#echo "sto = $sto"
#f="$sto"p
#echo -e "\e[33m+-----------------------------------------------------------------------------+\e[0m"
#echo -e "\e[33m$file :\e[0m"
#sed -n $sta,$f $file
#echo -e "\e[33m+-----------------------------------------------------------------------------+\e[0m"
echo -e "\e[33m+--------------------------------------------------------------------------------+\e[0m"
echo "Sum of electronic and zero-point Energies=   -> U(0) = E_DFT + ZPE"
echo "Sum of electronic and thermal Energies=      -> U(T) = E_DFT + ZPE + deltaU[0->T]"
echo "Sum of electronic and thermal Enthalpies=    -> H(T) =  E_DFT + ZPE + deltaH[0->T]"
echo "Sum of electronic and thermal Free Energies= -> G(T) = E_DFT + ZPE + deltaG[0->T]"
echo -e "\e[33m+--------------------------------------------------------------------------------+\e[0m"
#-------------------------------------------------------------------------------------#
E_ZPE=$(grep "Zero-point correction=" $file | awk '{print $3}')
e1=$(grep "Thermal correction to Energy=" $file | awk '{print $5}')
e2=$(grep "Thermal correction to Enthalpy=" $file | awk '{print $5}')
e3=$(grep "Thermal correction to Gibbs Free Energy=" $file | awk '{print $7}')
e4=$(grep "Sum of electronic and zero-point Energies=" $file | awk '{print $7}')
e5=$(grep "Sum of electronic and thermal Energies=" $file | awk '{print $7}')
e6=$(grep "Sum of electronic and thermal Enthalpies=" $file | awk '{print $7}')
e7=$(grep "Sum of electronic and thermal Free Energies=" $file | awk '{print $8}')
#echo "$e1 $e2 $e3 $e4 $e5 $e6 $e7"
delath=$(echo "scale=10;$e2-$E_ZPE" | bc )
delatH=$(echo $delath | awk '{printf("%.6f",$0)}')
hev=$(echo "scale=10;$delatH*$hartees" | bc )
#echo $delatH
Hev=$(echo $hev | awk '{printf("%.6f",$0)}')
#echo $Hev
ts=$(echo "scale=10;$e6 - $e7" | bc )
TS=$(echo $ts | awk '{printf("%.6f",$0)}')
#echo $TS
tsev=$(echo "scale=10;$TS*$hartees" | bc )
TSev=$(echo $tsev | awk '{printf("%.6f",$0)}')
#echo $TSev
#delatg=$(echo "scale=10;$e7 - $e4" | bc)
#delatG=$(echo $delatg | awk '{printf("%.6f",$0)}')
delatG=$e3
gev=$(echo "scale=10;$delatG*$hartees" | bc )
Gev=$(echo $gev | awk '{printf("%.6f",$0)}')
#echo $delatG
#echo $Gev
#echo $E_ZPE
zpeev=$(echo "scale=10;$E_ZPE*$hartees" | bc )
ZPE_ev=$(echo $zpeev | awk '{printf("%.6f",$0)}')
#echo $ZPE_ev
#echo -e "\e[33m$file Summary:\e[0m"
echo -e "\e[33m$file :\e[0m"
echo "----------------------------------------------------------------------------"
printf "%-6s %-10s %-12s %-10s %-12s %-10s %-8s %-4s\n" . E_ZPE U[0] U[T] H[T] G[T] Units .
printf "%-4s %-10s %-10s %-10s %-10s %-10s %-10s %-4s\n" . $E_ZPE $e4 $e5 $e6 $e7 Hartrees .
echo "----------------------------------------------------------------------------"
echo -e "\e[33m$file --> Summary:\e[0m"
echo "-------------------------------------------------------------"
printf "%-4s %-10s %-10s %-10s %-10s %-10s %-4s\n" . E_ZPE TS DelatH DelatG Units .
printf "%-4s %-10s %-10s %-10s %-10s %-10s %-4s\n" . $E_ZPE $TS $delatH $delatG Hartrees .
printf "%-4s %-10s %-10s %-10s %-10s %-10s %-4s\n" . $ZPE_ev $TSev $Hev $Gev eV .
echo "-------------------------------------------------------------"
#echo "273.15 K , 1 atm"
echo -e "\e[33m+--------------------------------------------------------------------------------+\e[0m"
























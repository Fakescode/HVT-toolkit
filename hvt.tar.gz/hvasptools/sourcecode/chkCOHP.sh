#!/bin/bash
#n1=$(grep "abs. charge spilling:" lobsterout)
#echo $n1
n=$(grep "abs. charge spilling:" lobsterout | awk '{print $4}')
m=$( echo ${n%%.*} )
#echo $m
echo "+-------------------------------------+"
if [ $m -le 5 ]; then
 echo -e "\e[33m--> The results of COHP were reliable \e[0m"
else
 echo -e "\e[33m--> Unreliable results \e[0m"
fi
echo "+-------------------------------------+"




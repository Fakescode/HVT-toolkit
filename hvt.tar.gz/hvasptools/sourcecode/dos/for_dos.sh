#!/bin/bash
echo """--> Plot the graphs of Density of States. 
--> 1. Plot the graphs of PDOS
		(using DOS*, split into orbitals)
--> 2. Plot the graphs of DOS 
		(for all atoms,split into orbitals or elements)  """
read -p "Select >"  f   #function
if [ $f == 1 ]; then

lorbit=$(grep -o '^[^#]*' INCAR | grep LORBIT | cut -d'=' -f2)
ispin=$(grep -o '^[^#]*' INCAR | grep ISPIN | cut -d'=' -f2)
#echo $lorbit $ispin
if [ $ispin == 2 ]; then
	if [ $lorbit == 10 ];then
		python $hvtpath/sourcecode/dos/plot_PDOS_10_2.py
	elif [ $lorbit == 11 ];then
		python $hvtpath/sourcecode/dos/plot_PDOS_atom_11_2.py
	else
		echo "Error, please check!"
	fi
elif [ $ispin == 1 ];then
	if [ $lorbit == 10 ];then
		python $hvtpath/sourcecode/dos/plot_PDOS_10_1.py
	elif [ $lorbit == 11 ];then
		python $hvtpath/sourcecode/dos/plot_PDOS_atom_11_1.py
	else
		echo "Error, please check!"
	fi
else
	echo "Error, please check!"
fi

elif [ $f == 2 ]; then
	python $hvtpath/sourcecode/dos/plot_dos_all_atom.py
else
	echo "Error, please check!"
fi

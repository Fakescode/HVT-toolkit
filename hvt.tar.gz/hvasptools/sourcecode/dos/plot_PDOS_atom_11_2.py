import os
import numpy as np
import matplotlib.pyplot as plt

plot_dos_in = input("""--> Select inputfile, e.g., DOS1 DOS2:  """)

xmin= -8
xmax= 4
fs=15
plt.figure(figsize=(10,6))
#plt.rcParams['font.family']=['Times New Roman']   #一些环境中没有新罗马字体

file=open(plot_dos_in,'r+')
lines=file.readlines()

x=[float(lines[i].strip().split()[0])for i in range(len(lines))]
y1=[float(lines[i].strip().split()[1])for i in range(len(lines))]     #s_up
y2=[float(lines[i].strip().split()[2])for i in range(len(lines))]     #s_dw
y3=[float(lines[i].strip().split()[3])for i in range(len(lines))]     #px_up
y4=[float(lines[i].strip().split()[4])for i in range(len(lines))]     #px_dw
y5=[float(lines[i].strip().split()[5])for i in range(len(lines))]     #py_up
y6=[float(lines[i].strip().split()[6])for i in range(len(lines))]     #py_dw
y7=[float(lines[i].strip().split()[7])for i in range(len(lines))]     #pz_up
y8=[float(lines[i].strip().split()[8])for i in range(len(lines))]     #pz_dw
y9=[float(lines[i].strip().split()[9])for i in range(len(lines))]     #dxy_up
y10=[float(lines[i].strip().split()[10])for i in range(len(lines))]   #dxy_dw
y11=[float(lines[i].strip().split()[11])for i in range(len(lines))]   #dyz_up
y12=[float(lines[i].strip().split()[12])for i in range(len(lines))]   #dyz_dw
y13=[float(lines[i].strip().split()[13])for i in range(len(lines))]   #dz2_up
y14=[float(lines[i].strip().split()[14])for i in range(len(lines))]   #dz2_dw
y15=[float(lines[i].strip().split()[15])for i in range(len(lines))]   #dxz_up
y16=[float(lines[i].strip().split()[16])for i in range(len(lines))]   #dxz_dw
y17=[float(lines[i].strip().split()[17])for i in range(len(lines))]   #dx2-y2_up
y18=[float(lines[i].strip().split()[18])for i in range(len(lines))]   #dx2-y2_dw

#-------------------------------------------------------------#
print("""--> Select orbital: s py pz px dxy dyz dz2 dxz dx2, "all" for plot ALL """)
plot_dos_select = [str(i) for i in input('--> ').split()]
#print(plot_dos_select) #check input
#-------------------------------------------------------------#

def plot_s():
    plt.plot(x,y1,label=r'$s$',color='orange')
    plt.plot(x,y2,color='orange')
def plot_px():
    plt.plot(x,y3,label=r'$p_{x}$',color='red',linestyle='-.')
    plt.plot(x,y4,color='red',linestyle='-.')
def plot_py():
    plt.plot(x,y5,label=r'$p_{y}$',color='blue',linestyle='--')
    plt.plot(x,y6,color='blue',linestyle='--')
def plot_pz():
    plt.plot(x,y7,label=r'$p_{z}$',color='cyan',linestyle=':')
    plt.plot(x,y8,color='cyan',linestyle=':')
def plot_dxy():
    plt.plot(x,y9,label=r'$d_{xy}$',color='red')
    plt.plot(x,y10,color='red')
def plot_dyz():
    plt.plot(x,y11,label=r'$d_{yz}$',color='blue')
    plt.plot(x,y12,color='blue')
def plot_dz2():
    plt.plot(x,y13,label=r'$d_{z^2}$',color='cyan')
    plt.plot(x,y14,color='cyan')
def plot_dxz():
    plt.plot(x,y15,label=r'$d_{xz}$',color='gray')
    plt.plot(x,y16,color='gray')
def plot_dx2_y2():
    plt.plot(x,y17,label=r'$d_{x^2-y^2}$',color='black')
    plt.plot(x,y18,color='black')
#-------------------------------------------------------------#
for i in plot_dos_select:
    if (i == "s"):
        #print("--> s is select")
        plot_s()
    elif (i == "px"):
        #print("--> px is select")
        plot_px()
    elif (i == "py"):
        #print("--> py is select")
        plot_py()
    elif (i == "pz"):
        #print("--> pz is select")
        plot_pz()
    elif (i == "dxy"):
        #print("--> dxy is select")
        plot_dxy()
    elif (i == "dyz"):
        #print("--> dyz is select")
        plot_dyz()
    elif (i == "dz2"):
        #print("--> dz2 is select")
        plot_dz2()
    elif (i == "dxz"):
        #print("--> dxz is select")
        plot_dxz()
    elif (i == "dx2"):
        #print("--> d_x2-y2 is select")
        plot_dx2_y2()
    elif (i == "all"):
        #print("--> Select all")
        plot_s()
        plot_px()
        plot_py()
        plot_pz()
        plot_dxy()
        plot_dyz()
        plot_dz2()
        plot_dxz()
        plot_dx2_y2()
    else:
        print("The programme can't handle this orbital.")


#-------------------------------------------------------------#
plt.xlim(xmin,xmax)
#plt.ylabel('Energy(eV)', fontsize = fs)
plt.ylabel('PDOS', fontsize = fs)
plt.xlabel('Energy(eV)', fontsize = fs)
plt.legend()
ax = plt.gca()
ax.tick_params(labelsize=fs)
plt.legend(frameon=False) #去掉图例边框
plt.savefig("dos.png",format='png',  dpi=500)

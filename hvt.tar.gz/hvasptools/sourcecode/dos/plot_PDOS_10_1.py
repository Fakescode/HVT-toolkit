import os
import numpy as np
import matplotlib.pyplot as plt

plot_dos_in = input("""--> Select inputfile, e.g., DOS1 DOS2:  """)

xmin= -8
xmax= 4
fs=15
plt.figure(figsize=(10,6))
#plt.rcParams['font.family']=['Times New Roman']   #一些环境中没有新罗马字体

file=open(plot_dos_in,'r+')
lines=file.readlines()

x=[float(lines[i].strip().split()[0])for i in range(len(lines))]
y1=[float(lines[i].strip().split()[1])for i in range(len(lines))]     #s
y2=[float(lines[i].strip().split()[2])for i in range(len(lines))]     #p
y3=[float(lines[i].strip().split()[3])for i in range(len(lines))]     #d

#-------------------------------------------------------------#
print("""--> Select orbital: s p d, "all" for plot ALL """)
plot_dos_select = [str(i) for i in input('--> ').split()]
#print(plot_dos_select) #check input
#-------------------------------------------------------------#

def plot_s():
    plt.plot(x,y1,label=r'$s$',color='red')
def plot_p():
    plt.plot(x,y2,label=r'$p_{x}$',color='blue')
def plot_d():
    plt.plot(x,y3,label=r'$p_{y}$',color='black')

#-------------------------------------------------------------#
for i in plot_dos_select:
    if (i == "s"):
        #print("--> s is select")
        plot_s()
    elif (i == "p"):
        #print("--> p is select")
        plot_p()
    elif (i == "d"):
        #print("--> s is select")
        plot_d()
    elif (i == "all"):
        #print("--> Select all")
        plot_s()
        plot_p()
        plot_d()
    else:
        print("The programme can't handle this orbital.")


#-------------------------------------------------------------#
plt.xlim(xmin,xmax)
#plt.ylabel('Energy(eV)', fontsize = fs)
plt.ylabel('PDOS', fontsize = fs)
plt.xlabel('Energy(eV)', fontsize = fs)
plt.legend()
ax = plt.gca()
ax.tick_params(labelsize=fs)
plt.legend(frameon=False) #去掉图例边框
plt.savefig("dos.png",format='png',  dpi=500)

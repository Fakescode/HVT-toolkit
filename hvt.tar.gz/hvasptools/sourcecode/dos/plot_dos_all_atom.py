import matplotlib.pyplot
from pymatgen.io.vasp.outputs import Vasprun
from pymatgen.electronic_structure.plotter import BSDOSPlotter,\
     BSPlotter,BSPlotterProjected,DosPlotter
dos_vasprun=Vasprun("vasprun.xml")
dos_data=dos_vasprun.complete_dos

plt_1=DosPlotter(stack=False,sigma=0.5)
plt_1.add_dos('total dos',dos=dos_data)
plt_1.add_dos_dict(dos_data.get_spd_dos())
plt_1.save_plot('dos-orbital.png', img_format=u'png')

plt_2=DosPlotter(stack=False,sigma=0.5)
plt_2.add_dos('total dos',dos=dos_data)
plt_2.add_dos_dict(dos_data.get_element_dos())
plt_2.save_plot('dos-atom.png', img_format=u'png')

#!/bin/bash
hvt -ipt
mkdir cineb freq-cineb idm
mv POSCAR-ini POSCAR-fin 0* cineb
cd cineb
mkdir ini fin
mv POSCAR-ini ini
mv POSCAR-fin fin
hvt -cineb
cat > KPOINTS <<!
KPOINTS
0
Monkhorst-Pack
   1   1   1
0.0  0.0  0.0
!
cd ../freq-cineb
cat > KPOINTS <<!
KPOINTS
0
Monkhorst-Pack
   1   1   1
0.0  0.0  0.0
!
hvt -freq
cd ../idm
hvt -idimer
cat > KPOINTS <<!
KPOINTS
0
Monkhorst-Pack
   1   1   1
0.0  0.0  0.0
!

#!/bin/bash
echo "--> Spin Density"
read -p "--> CHGCAR_file = " chg
echo "--> Reading total charge density and magnetization density ..."
perl $hvtpath/bin/Tools/chgdiff.pl $chg > netspin.log
rm -rf netspin.log CHGCAR_tot
mv CHGCAR_mag spin.vasp
echo "--> Output: spin.vasp"
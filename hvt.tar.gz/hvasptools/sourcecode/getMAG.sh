#!/bin/bash
#This scripts is use to get the MAG-export in OUTCAR
#To use this scripts you should firstly do a scf cal use LORBIT  parameter in INCAR.
#version:1.0
#author: Hanbin_He
echo -e "\e[33m-->Script for extracting magnetization\e[0m"
sta=$(grep -n "magnetization (x)" OUTCAR | awk '{print $1}' |tail -1|tr -d ':')
sto=$(grep -n "total amount of memory" OUTCAR | awk '{print $1}' |tail -1|tr -d ':' )
f="$sto"p
sed -n $sta,$f OUTCAR > magnetization
sed -i '$d' magnetization
#sed -i '1d' magnetization
echo -e "\e[33m-->Operation complete, output file: magnetization\e[0m"

#!/bin/sh
# author: Hanbin
echo "--> Please select a drawing format:
--> 1. Normal energy band diagram.  
--> 2. Energy band diagrams projected onto elements. 
--> 3. Banddos diagram (band: ordinary; dos: elemental).
--> 4. Banddos diagram (band: elemental; dos: elemental).
--> 5. Banddos diagram (band: elemental; dos: orbit).    "
read -p "--> Select: " n
if [ $n == 1 ];then
    echo "--> Band plotter starting ... "
    python $hvtpath/sourcecode/bands/h-band-all.py
    echo "--> Finish, output: band_plot.png"
elif [ $n == 2 ] ; then
    echo "--> Band plotter starting ... "
    python $hvtpath/sourcecode/bands/h-band-element.py
    echo "--> Finish, output: band_element.png "
elif [ $n == 3 ] ; then
    python $hvtpath/sourcecode/bands/plotbanddos-all.py
elif [ $n == 4 ] ; then
    python $hvtpath/sourcecode/bands/plotbanddos-ele.py
elif [ $n == 5 ] ; then
    python $hvtpath/sourcecode/bands/plotbanddos-orbitals.py
else
    echo "Error input ..."
fi




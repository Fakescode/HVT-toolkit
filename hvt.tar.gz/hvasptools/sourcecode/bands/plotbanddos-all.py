import matplotlib.pyplot as plt
import matplotlib as mpl
mpl.use('Agg')
from pymatgen.io.vasp.outputs import Vasprun
from pymatgen.electronic_structure.plotter import BSDOSPlotter,\
BSPlotter,BSPlotterProjected,DosPlotter

print("--> Getting band and dos information from vasprun.xml ...")

# vasprun.xml: read the information of band and dos 
bs_vasprun = Vasprun("vasprun.xml",parse_projected_eigen=True)
bs_data = bs_vasprun.get_band_structure(line_mode=True)

dos_vasprun=Vasprun("vasprun.xml")
dos_data=dos_vasprun.complete_dos

print("--> Start drawing ...")

# draw figure
plt_1 = BSDOSPlotter(bs_projection=None, dos_projection=None)
plt_1.get_plot(bs=bs_data,dos=dos_data)
plt.legend(loc="upper right" )   #这是个成功的案例, 位置设定：上边：upper left , upper center , upper right， 中间：center left , center , center right，下边：lower left , lower center , lower right，
plt.savefig('dosbands.png')


print("--> Operation complete, output: dosbands.png ")

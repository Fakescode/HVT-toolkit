import sys
import numpy as np

import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.gridspec import GridSpec

from pymatgen.io.vasp.outputs import Vasprun
from pymatgen.electronic_structure.core import Spin, OrbitalType
from pymatgen.electronic_structure import plotter
from pymatgen.electronic_structure.plotter import BSDOSPlotter, BSPlotter, BSPlotterProjected, DosPlotter


dosrun = Vasprun("vasprun.xml")
dos_data = dosrun.complete_dos
spd_dos = dosrun.complete_dos.get_spd_dos()

# bands
bs_run = Vasprun("vasprun.xml", parse_projected_eigen=True)
bs_data = bs_run.get_band_structure("KPOINTS",
                               line_mode=1)
bands = bs_run.get_band_structure("KPOINTS",
                               line_mode=True,
                               efermi=dosrun.efermi)


plot1 = BSDOSPlotter(bs_projection = None)
plot1.get_plot(bs=bs_data)
plt.legend(loc="upper right" )   #这是个成功的案例, 位置设定：上边：upper left , upper center , upper right， 中间：center left , center , center right，下边：lower left , lower center , lower right，
plt.savefig('band_plot.png',dpi=300)
plt.show() 





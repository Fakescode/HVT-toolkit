import matplotlib.pyplot as plt
import matplotlib as mpl
mpl.use('Agg')
from pymatgen.io.vasp.outputs import Vasprun
from pymatgen.electronic_structure.plotter import BSDOSPlotter,\
BSPlotter,BSPlotterProjected,DosPlotter

print("--> Getting band and dos information from vasprun.xml ...")
bs_vasprun = Vasprun("vasprun.xml",parse_projected_eigen=True)
bs_data = bs_vasprun.get_band_structure(line_mode=True)
dos_vasprun=Vasprun("vasprun.xml")
dos_data=dos_vasprun.complete_dos
print("--> Start drawing ...")
plt_1 = BSDOSPlotter(bs_projection='elements', dos_projection='orbitals')
plt_1.get_plot(bs=bs_data,dos=dos_data)
plt.legend(loc="upper right" )   #这是个成功的案例, 位置设定：上边：upper left , upper center , upper right， 中间：center left , center , center right，下边：lower left , lower center , lower right，
plt.savefig('dosbands_orbitals.png')
print("--> Operation complete, output: banddos_orbitals.png ")
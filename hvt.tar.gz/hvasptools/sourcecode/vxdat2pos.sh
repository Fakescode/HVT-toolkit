#!/bin/bash
#Hanbin_He
stty erase ^h
stty erase ^?
stty erase ^H
echo -e "\e[33m+--------------------------------------------------+\e[0m"
echo -e "\e[33m|      Script to deal XDATCAR generate by AIMD     |\e[0m"
echo -e "\e[33m+--------------------------------------------------+\e[0m"
echo -e "\e[33m|1.Generate all images | 2.Generate selected images|\e[0m"
echo -e "\e[33m+--------------------------------------------------+\e[0m"
read -p "Enter your select >"  n
mkdir MDposfile
cp XDATCAR OSZICAR MDposfile
cd MDposfile
sum_atoms=$(cat XDATCAR | sed -n '7p' | awk '{for (i=1;i<=NF;i++) sum+=$i; print sum}')
sum_steps=$(grep F= OSZICAR | awk '{print $1}')
if [ $n == 1 ] ; then
for j in $sum_steps
do
awk '{if (NR<8) print $0}' XDATCAR > POSCAR-$j
grep -xA $sum_atoms "Direct configuration=$j" XDATCAR >> POSCAR-$j
grep -xA $sum_atoms "Direct configuration= $j" XDATCAR >> POSCAR-$j
grep -xA $sum_atoms "Direct configuration=  $j" XDATCAR >> POSCAR-$j
grep -xA $sum_atoms "Direct configuration=   $j" XDATCAR >> POSCAR-$j
grep -xA $sum_atoms "Direct configuration=    $j" XDATCAR >> POSCAR-$j
grep -xA $sum_atoms "Direct configuration=     $j" XDATCAR >> POSCAR-$j
done
cd ..
#elif [ $n == 3 ] ; then
#read -p "Please enter the number of images to be output >"  j
#awk '{if (NR<8) print $0}' XDATCAR > POSCAR-$j  #This scheme can only extract one at a time, and thus not use
#grep -xA $sum_atoms "Direct configuration=   $j" XDATCAR >> POSCAR-$j
#grep -xA $sum_atoms "Direct configuration=    $j" XDATCAR >> POSCAR-$j
#grep -xA $sum_atoms "Direct configuration=     $j" XDATCAR >> POSCAR-$j
#cd ..
elif [ $n == 2 ] ; then
num_steps=$(grep F= OSZICAR | awk '{print $1}' |tail -1)
echo -e "\e[33mA total of $num_steps images are detected in XDATCAR \e[0m"
read -p "Please enter the number of images to be output > "
#echo $REPLY
for s in $REPLY
do
awk '{if (NR<8) print $0}' XDATCAR > POSCAR-$s
grep -xA $sum_atoms "Direct configuration=$s" XDATCAR >> POSCAR-$s
grep -xA $sum_atoms "Direct configuration= $s" XDATCAR >> POSCAR-$s
grep -xA $sum_atoms "Direct configuration=  $s" XDATCAR >> POSCAR-$s
grep -xA $sum_atoms "Direct configuration=   $s" XDATCAR >> POSCAR-$s
grep -xA $sum_atoms "Direct configuration=    $s" XDATCAR >> POSCAR-$s
grep -xA $sum_atoms "Direct configuration=     $s" XDATCAR >> POSCAR-$s
done
cd ..
else
echo "Program Exit"
cd ..
rm -rf MDposfile
fi

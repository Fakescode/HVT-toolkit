#!/bin/sh
# https://www.vasp.at/wiki/index.php/Calculate_U_for_LSDA%2BU
# Written by Hanbin.
# Version: 8.0

#Range Setting
MAX=0.20   #最大区间,参考官网案例
MIN=-0.20  #最小区间,参考官网案例
STEP=0.05  #计算步长,参考官网案例

if [ -f POSCAR ]; then
cp POSCAR POSCAR.0
else
startpro=1 #这个定义哈确实没用。
fi
#Start Menu
echo "  *** Script for Linear response calculation of U ***
--> Select the calculation you want to perform:
    0.Instructions; 
    1.Input example;                                  
    2.DFT groudstate;                                 
    3.SCF and NSCF for DFT+U(After 2); 
    4.Submit all calculations(After 3);
    5.Extract Ueff data(After 3).    
    6.Linear fitting of the potential and the number of electrons (drawing)"
read -p "--> "  command1        #这个是主菜单判断

if [ $command1 == 0 ];then
echo "-->
1). Create a new folder and prepare the calculation file;
2). Write the commit command script inside the sub.sh
3). Input file cases can be generated using function 1;
4). Run the function after preparing the input file 2;
5). Considering the different server environments, 
    this function does not provide a batch submission function;
6). First go to the 1-DFT folder to check and submit calculations;
7). Then run function 3 and go to the 2-NCSF+SCF folder to check and submit all the tasks;
8). After the above calculations are completed run function 4 to calculate and output the results;
9). The output file is Udata.log and its last line is the calculated U value;
10). Access to special folders command: cd -- -0.20;
11). Add "--" to all operations on folders named "-0.XX", e.g. 10)；
12). tebiezhu Special note: It is recommended that calculations be performed with protocells.
"
elif [ $command1 == 1 ];then
    echo "--> Please enter the input file you want to generate:                                                   
    1.INCAR(Incomplete)                                         
    2.KPOINTS  
    3.POTCAR    "
    read -p "--> "  command2  #command2判断要制作啥输入文件
    if (( ${command2}==1 )); then
       cat>INCAR<<!
SYSTEM=U_eff_Linear
PREC=A
EDIFF=1E-5
ISMEAR=0
SIGMA=0.2
ISPIN=2
MAGMOM=    #use hvt -magin
LORBIT=11  #or LORBIT=10
!
    echo -e "--> Finish. "
    elif ((${command2}==2))  ; then
       cat>KPOINTS<<!
KPOINTS-MP
0
Monkhorst-Pack
 1   1   1
0.0 0.0 0.0
!
    echo -e "--> Finish. "
    elif ((${command2}==3))  ; then
    hvt -pbe
    echo -e "--> Finish. "
    else
    echo "--> Error input"
    fi


elif [ $command1 == 2 ];then
E_num=$(sed -n 6p POSCAR| tr -d "\r" | wc -w)
#echo "n(Elements): $E_num"         #元素数量统计
Q=
for (( i=1 ; i<=$E_num ; i++ ))
do
    #echo "$i"     # for check
    E=$(sed -n 6p POSCAR| tr -d "\r" | awk '{print $'$i'}')  #元素
    #Q1="$E ~ $i"
    Q1="$i-$E"
    Q="$Q $Q1"
done
#echo $Q
echo "--> Select the element by number to calculate the U value($Q ):"
    #echo "--> The atom you want to calculate the U value in POSCAR: "
    read -p "--> " n_atom
    if [ -f input.log ];then
        rm -rf input.log
    else
        mmmmm=1 #随机定义，没有任何意义
    fi
    echo $n_atom>>input.log
    echo "--> Number of the orbital you want to calculate the U value:1-p;2-d;3-f"
    read -p "--> " n_orbital
    echo $n_orbital>>input.log
    sed -i "s/MAGMOM/#MAGMOM/g" INCAR    #注释掉MAGMOM参数
    sed -i "s/ICHARG/#ICHARG/g" INCAR    #注释掉ICHARG参数
#-----------------> 重构 LMAXMIN 参数 <------------------#
if [ $n_orbital == 2 ] || [ $n_orbital == 2 ];then
        l_max=$(echo "LMAXMIX = 4")
elif [ $n_orbital == 3 ];then
        l_max=$(echo "LMAXMIX = 6")
else
        l_max=$(echo "LMAXMIX = 4")  #默认先按照4来用
fi 
#---------------> LMAXMIX要根据轨道判断 <----------------#
#hvt -pbe
#DFT
mkdir 1-DFT
cd 1-DFT
cp ../INCAR ../POSCAR ../POTCAR ../KPOINTS ./
cd ..
mkdir "2-NCSF+SCF"
cd "2-NCSF+SCF"
    for i in $(seq ${MIN} ${STEP} ${MAX})
        do
        mkdir -- "$i"
        cd -- $i
        mkdir 1-U-NSCF 2-U-SCF
        cp ../../INCAR ../../POSCAR ../../POTCAR ../../KPOINTS 1-U-NSCF
        cp ../../INCAR ../../POSCAR ../../POTCAR  ../../KPOINTS 2-U-SCF        
        cd 1-U-NSCF
        echo "ICHARG=11">>INCAR 
        echo $l_max >> INCAR
        cd ../2-U-SCF
        echo "ICHARG=1">>INCAR
        echo $l_max >> INCAR
        cd ../../
    done
echo -e "--> Finish. "

elif [ $command1 == 3 ];then    
        s_atom=$(echo $(head -1 input.log|awk '{print $1}'))
        s_orbital=$( echo $(head -2 input.log|tail -1|awk '{print $1}'))
        Num_ELE=$(sed -n 6p POSCAR| tr -d "\r" | wc -w)  
cd 2-NCSF+SCF 
    for file in $(seq ${MIN} ${STEP} ${MAX})
        do          
        cd -- ${file}
        for items in 1 2
            do
            if [ $items == 1 ];then
            cd 1-U-NSCF                       #进入1-U-NSCF文件夹
            cp ../../../1-DFT/CHGCAR ./
            cp ../../../1-DFT/WAVECAR ./  
            else
            cd 2-U-SCF                        #进入1-U-NSCF文件夹
            cp ../../../1-DFT/CHGCAR ./
            cp ../../../1-DFT/WAVECAR ./           
            fi
#------------------------------------------------------------> good
A=-1    #U的参数
B=0     #U的参数
   num=0   #用于判断当前
   s=3  
   for ((i=1;i<=$Num_ELE;i++))
   do
            if [ $num -lt $Num_ELE ];then      #-le是小于等于，-lt是小于
            num=$[$num+1]
            #echo $num
#-------------------------------------------------------
        if [ $num == $s_atom ];then                
        LDAUL=""
        LDAUU=""
        LDAUJ=""
                for ((j=1;j<=${Num_ELE};j++))
                    do 
                    if [ $j == $i ];then
                        LDAUL="$LDAUL ${s_orbital} "
                        LDAUU="$LDAUU ${file} "
                        LDAUJ="$LDAUJ ${file} "
                    #elif [ $j != $i ];then
                    else
                        LDAUL="$LDAUL $A"
                        LDAUU="$LDAUU $B"
                        LDAUJ="$LDAUJ $B"
                    fi   
                    done              
echo "LDAU=.TRUE.
LDAUTYPE = 3   #Linear response ansatz of Cococcioni et al. to compute U
LDAUL = $LDAUL
LDAUU = $LDAUU
LDAUJ = $LDAUJ">>INCAR
break
            fi          
            if  (( $num<$s_atom ));then  
                 continue
            fi
#-------------------------------------------------------------------------------
            else
            num=$num
            fi
    done
cd ..
done
cd ..
done
cd ..
echo -e "--> Finish. "
#-------------------------------------------------------------------------------
elif [ $command1 == 4 ];then
    cd 2-NCSF+SCF 
        for file in $(seq ${MIN} ${STEP} ${MAX})
        do          
        cd -- ${file}
            for items in 1 2
            do
            if [ $items == 1 ];then
                cd 1-U-NSCF    #进入1-U-NSCF文件夹
                echo "Place the execution script in this folder and write the execution command in this file">sub.sh                      
                echo "Example: sbatch sub.batch">sub.sh
                chmod +x sub.sh
                ./sub.sh
            else
                cd 2-U-SCF                        #进入1-U-NSCF文件夹
                echo "Place the execution script in this folder and write the execution command in this file">sub.sh                      #进入1-U-NSCF文件夹
                echo "Example: sbatch sub.batch">sub.sh
                chmod +x sub.sh
                ./sub.sh           
            fi
            done
        done
#-------------------------------------------------------------------------------
elif [ $command1 == 5 ];then
    item=0
    atoms_num=$(echo $(head -1 input.log|awk '{print $1}'))
    orbit=$( echo $(head -2 input.log|tail -1|awk '{print $1}'))
#--------------------> 判断一下加U元素的第一个原子的原子序号
a_num=$(sed -n 7p POSCAR| tr -d "\r" )
num_a=1
nn_atom_1=1    #定义一个空集
NNum_ELE=$(sed -n 7p POSCAR| tr -d "\r" | wc -w) 
#echo $NNum_ELE
for ((i=1;i<=$NNum_ELE;i++))
do
	#echo $i
	nn_start=$(echo $a_num | awk '{print $('$i')}') #bug在这
	#echo $nn_start 
	num_a=$(($nn_start+$num_a))
#	echo $num_a
	nn_atom_1="$nn_atom_1 $num_a"
	#echo $nn_atom_1
done
first_a=$( echo $nn_atom_1 | awk '{print $('$atoms_num')}' )
#echo $first_a
#echo $first_a $atoms_num 
#echo "$nn_atom_1"
#echo "------->"
#-----------------------------------------------> #first_a就是选定的元素的第一个原子，之后的计算的U就是针对这个原子进行的


    #----------------------------------------------->
#CHG-DFT
    cd -- 1-DFT
    chgDFT=`grep -$((first_a+3)) "total charge" OUTCAR|tail -1|awk '{print $((E+2))}' E="$orbit" `
    cd ..
printf "%6s %8s %8s %8s\n" "U  " "DFT " "NSCF" "SCF " >Udata.log
printf "%6s %8s %8s %8s\n" "-----" "-----" "-----" "-----" >>Udata.log
for i in $(seq ${MIN} ${STEP} ${MAX})
    do
        item=$((item+=1)) 
        cd 2-NCSF+SCF   
        cd -- $i
#CHG-NSCF
        cd -- 1-U-NSCF
        chgNSCF=`grep -$((first_a+3)) "total charge" OUTCAR|tail -1|awk '{print $((E+2))}' E="$orbit" `
#CHG-SCF
        cd -- ../2-U-SCF
        chgSCF=`grep -$((first_a+3)) "total charge" OUTCAR|tail -1|awk '{print $((E+2))}' E="$orbit" `
        if [ $(bc <<< "$i == $MIN") -eq 1 ] ;then
            CHGDIFF_NSCF1=$chgNSCF
            CHGDIFF_SCF1=$chgSCF
        fi
        if [ $(bc <<< "$i == $MAX") -eq 1 ] ;then
            CHGDIFF_NSCF2=$chgNSCF
            CHGDIFF_SCF2=$chgSCF
            DELTA_V=$(echo "scale=3;$item*$STEP-$STEP"|bc )
            XSCF=`awk -v m1=$CHGDIFF_SCF1 -v m2=$CHGDIFF_SCF2 -v DELTA_V=$DELTA_V 'BEGIN{print m2/DELTA_V-m1/DELTA_V}'`
            XNSCF=`awk -v m1=$CHGDIFF_NSCF1 -v m2=$CHGDIFF_NSCF2 -v DELTA_V=$DELTA_V 'BEGIN{print m2/DELTA_V-m1/DELTA_V}'`
            Ueff=`awk -v m1=$XSCF -v m2=$XNSCF 'BEGIN{print 1/m1-1/m2}'`
        fi
        cd ..
        cd ..
        cd ..
        printf "%6s %8s %8s %8s\n" $i $chgDFT $chgNSCF $chgSCF >>Udata.log
    done
        printf "%6s %8s %8s %8s\n" "-----" "-----" "-----" "-----" >>Udata.log
        echo " " >>Udata.log
        echo "*** Results: ***">> Udata.log
        printf "%6s %8s\n" "Ueff:" "$Ueff" >>Udata.log
echo -e "-->  "
#------------------------------->
E_element=$(sed -n 6p POSCAR| tr -d "\r" )
a_num=$(sed -n 7p POSCAR| tr -d "\r" )
ss_atom=$(echo $E_element | awk '{print $('$atoms_num')}')  #选定的元素
nn_atom=$(echo $a_num | awk '{print $('$atoms_num')}')      #选定的元素的原子数
first_a=$( echo $nn_atom_1 | awk '{print $('$atoms_num')}' )

echo "*** Select information *** " > Uout.dat
echo "   +=============================+">>Uout.dat
printf "%4s %8s %8s %9s %1s\n"  "|" Element cal_num atom_num "|">>Uout.dat
echo "   |-----------------------------|">>Uout.dat
printf "%4s %8s %8s %9s %1s\n"  "|" $ss_atom $first_a $nn_atom "|">>Uout.dat
echo "   +=============================+">>Uout.dat
echo " " >>Uout.dat
echo "*** Data *** " >> Uout.dat
#------------------------------->
cat Udata.log >> Uout.dat
cat Uout.dat
#rm -rf Udata.log input.log
rm -rf Udata.log 

#---------------------------------------------------> Plot
elif [ $command1 == 6 ];then
#sed -n '11,19p' Uout.dat >uplot.dat
#gnuplot <<EOF
#set terminal postscript
#set output "Ueff.eps"
#set key top center
#set xlabel "U (eV)"; set xrange [-0.2:0.2]; set xtics -0.2,0.05,0.2 scale 1
#set ylabel "number of d-electrons"; 
#set lmargin at screen 0.15
#set rmargin at screen 0.96
#set tmargin at screen 0.96
#set bmargin at screen 0.20
#plot "uplot.dat" using 1:3 with linespoints pointtype 5 pointsize 1 title "NSCF","uplot.dat" using 1:4 with linespoints pointtype 7 pointsize 1 title "SCF"
#set output
#EOF
#----------------------------
sed -n '11,19p' Uout.dat >uplot.dat
nscf1=$(sed -n 1p uplot.dat | awk '{print $3}')
scf1=$(sed -n 1p uplot.dat | awk '{print $4}')
nscf2=$(sed -n 9p uplot.dat | awk '{print $3}')
scf2=$(sed -n 9p uplot.dat | awk '{print $4}')
y_nscf=$(echo $nscf2-$nscf1 |bc)
y_scf=$(echo $scf2-$scf1 |bc)
x_scf=0.4
slope_nscf=`echo "scale=4; $y_nscf/$x_scf" | bc`
slope_scf=`echo "scale=4; $y_scf/$x_scf" | bc`
cal_slope_scf=`echo "scale=4; 1/$slope_scf" | bc`
cal_slope_nscf=`echo "scale=4; 1/$slope_nscf" | bc`
ueff_cu=$(echo $cal_slope_scf-$cal_slope_nscf |bc | awk '{printf "%.4f", $0}')
xielv_nscf=$(echo $slope_nscf | awk '{printf "%.4f", $0}')
xielv_scf=$(echo $slope_scf | awk '{printf "%.4f", $0}')
gnuplot <<EOF
set terminal postscript
set output "Ueff.eps"
set xlabel "U (eV)"; set xrange [-0.2:0.2]; set xtics -0.2,0.05,0.2 scale 1
set ylabel "Number of electrons"; 
set lmargin at screen 0.15
set rmargin at screen 0.96
set tmargin at screen 0.96
set bmargin at screen 0.20
set key left
plot "uplot.dat" using 1:4 with linespoints pointtype 5 pointsize 1 title "SCF-Kscf=$xielv_scf","uplot.dat" using 1:3 with linespoints pointtype 7 pointsize 1 title "NSCF-Knscf=$xielv_nscf"
set output
EOF
rm -rf uplot.dat
echo "--> Finish, output: Ueff.eps"
else
echo "Error input"
fi

#/bin/bash
stty erase ^h
stty erase ^?
stty erase ^H
echo "--> OUTCAR information analysis script
   1.Fermi level           2.Inverse lattice
   3.Valence electrons     4.Cell volume
   5.Total energy          6.Ion step time
   7.Electronic step time  8.Convergence"  
#1.费米能级 #2.倒格基矢 #3.体系中原子的受力情况 #4.体系的体积 #5.体系的总能 #6.每一个离子步花去的时间 #7.每一个电子步以及离子步花去的时间 #8.每一个电子步以及离子步花去的时间 #9.有无收敛
read -p "--> " nn
if [ $nn == 1 ];then
	grep fermi OUTCAR | tail -1
elif [ $nn == 2 ] ; then
	grep irreducible OUTCAR # grep irre OUTCAR
elif [ $nn == 3 ] ; then
	e=
	t=$( grep TITEL OUTCAR | awk '{ print $4 }' )
	z=$( grep ZVAL OUTCAR | awk '{ print $6 }' )
	n=$( grep TITEL OUTCAR | awk '{ print $4 }' | wc -w )
	for (( b=1 ; b<=$n ; b++ ))
           do
	        t1=$( echo $t | awk '{print $'$b'}')
		z1=$( echo $z | awk '{print $'$b'}')
                e="$t1 ~ $z1"
                e1="$e1  $e"
           done
	echo " $e1 "
elif [ $nn == 4 ] ; then
        grep volume OUTCAR
elif [ $nn == 5 ] ; then
        grep without OUTCAR | tail -1 | awk '{print $1" "$2" "$3" "$4}'
elif [ $nn == 6 ] ; then
        grep LOOP+ OUTCAR
elif [ $nn == 7 ] ; then
        grep LOOP OUTCAR
elif [ $nn == 8 ] ; then
        grep required OUTCAR
else
	echo "Features are under development"
fi

#stty erase ^h
#stty erase ^?
#stty erase ^H

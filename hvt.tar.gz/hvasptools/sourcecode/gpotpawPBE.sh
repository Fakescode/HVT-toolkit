#!/bin/bash
#This script is used to produce a POTCAR without a suffix.
#Unless you must use a pseudopotential without a suffix, vaspkit is recommended for POTCAR generation.
#-----------------------------------------------------------------------------------------------------#
#dos2unix POSCAR #Some servers may not have dos2unix.
rm -f POTCAR
#grep -wB 2 "Direct" POSCAR |head -1 >POS.log
sed -n 6p POSCAR >POS.log
num=$(awk '{print NF}' POS.log)
for ((i=1;i<=$num;i++))
do
POT=`awk -v a=$i '{print $a}' POS.log`
#cat /home/hanbin/test/vasp.5.pot/potpaw_PBE/$POT/POTCAR >> POTCAR
cat /home/hanbin/soft/vasp.5.pot/potpaw_PBE/$POT/POTCAR >> POTCAR
done
rm POS.log

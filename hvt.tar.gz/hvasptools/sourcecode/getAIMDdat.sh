#!/bin/bash
#This scripts is use to get the MAG-export in OUTCAR
#To use this scripts you should firstly do a scf cal use LORBIT  parameter in INCAR.
#version:1.0
#author: Hanbin_He
echo -e "\e[33m-->Script for extracting AIMD data\e[0m"
grep 'F=' OSZICAR|awk '{print $1, "\t"$3,"\t"$9}' >AIMDout.dat
echo -e "\e[33m-->Operation complete, output file: AIMDout.dat\e[0m"

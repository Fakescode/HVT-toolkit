#!/usr/bin/env python
# -*- coding: utf-8 -*-
# version:5.0
# author: Hanbin
# If the drawing fails, check your running environment. 
import numpy as np
import matplotlib.pyplot as plt
print("""--> @ 1. Default, Drawing with default parameters for correction.
    @ 2. Inputting correction parameters to modify the COHP diagram.
    @ 3. Drawing with the output file to other drawing software.""")
plotstep = input("""--> select :  """)
print("--> Now reading COHPCAR.lobster...")
def remove_lines_from_file(file_name,num_lines):
    with open(file_name,'r') as file:
        lines = file.readlines()
    remaining_lines = lines[num_lines:]
    with open(file_name2,'w') as file:
        file.writelines(remaining_lines)
file_name = 'COHPCAR.lobster'
file_name2 = 'COHPCAR.plot'
num_lines = 4
remove_lines_from_file(file_name,num_lines)
#读取并删除COHPCAR.lobster删除前四行保存至COHPCAR.plot
print("--> Data processing, output: COHPCAR.plot")
#------------------------------------------------------------#
print("--> Now reading ICOHPCAR.lobster...")
with open("ICOHPLIST.lobster", "r") as f:
    lines = [line.strip() for line in f]
line2 = lines[1]
#print(line2)
shuzhi = line2.split()
icohp1 = shuzhi[7]
icohp1 = float(icohp1)
#print(icohp1)
num_lines = len(lines)
#print(num_lines)
if(num_lines>2):
    line4 = lines[3]
    shuzhi2 = line4.split()
    icohp2 = shuzhi2[7]
    icohp2 = float(icohp2)
    icohp = icohp1 + icohp2
    #print("ICOHP = %f" % (icohp))
else:
    icohp = icohp1
    #print(icohp1)
#----------------------------------------------------------------#
icohp = ('%.2f'%icohp)
if(plotstep == "1"):
    print("--> Start drawing...")
    xlab="Energy (eV)"
    ylab="-COHP"
    fs=15
    fz=[8,4]
    fn="COHPCAR.plot"
    savefn="cohp.png"
    #plt.rcParams['font.family']=['Times New Roman'] #有的环境没有该字体
    file=open(fn,'r+')
    lines=file.readlines()
    x=[float(lines[i].strip().split()[0])for i in range(len(lines))]
    y1=[-1*float(lines[i].strip().split()[1])for i in range(len(lines))]
    fig=plt.figure(figsize=fz)
    ax=plt.subplot(111)
    ax.plot(x,y1,label=ylab,color='black')
    #ax.legend()
    plt.ylabel(ylab, fontsize = fs)
    plt.xlabel(xlab, fontsize = fs)
    #ax.set_xlim(xmax = 4)
    y2=np.array(y1)
    plt.fill_between(x,y1,where=0>y2,color='blue',alpha=.5)
    plt.fill_between(x,y1,where=0<y2,color='yellow',alpha=.7)
    resulty = np.min(y1)
    resultx = np.min(x)
    #plt.text(3.85,resulty-0.5,'ICOHP=%s'%icohp,ha='right',fontsize=12)# 在图中添加文字
    plt.text(resultx,resulty+0.5,'ICOHP=%s'%icohp,ha='left',fontsize=12)# 在图中添加文字
    plt.axhline(y=0,ls="dashed",c="black")
    plt.axvline(x=0,ls=":",c="black")
    plt.savefig(savefn,format='png',bbox_inches='tight',  dpi=500)
    print("--> Done, output: cohp.png")
#----------------------------------------------------------------#
elif(plotstep == "2"):
    xmax_v = input("""--> Maximum value of x-coordinate :  """)
    xmin_v = input("""--> Minimum value of x-coordinate :  """)
    #ymax_v = input("""--> Maximum value of y-coordinate :  """)  #此处设置y轴范围没意义
    #ymin_v = input("""--> Minimum value of y-coordinate :  """)
    fig_name = input("""--> Name of the figure : """)
    font_size = input("""--> Setting the font size of scale values(xticks and yticks)(default : 12): """)
    font_size2 = input("""--> Setting the font size of ICOHP label(default : 12): """)
    font_size3 = input("""--> Setting the font size of figure name(default : 12): """)
    label_size = input("""--> Setting the font size of xlabel and ylabel(default : 15): """)
    #bond_color = input("""--> Set the color of the bonding area""") #颜色就算了，我觉得黄蓝就很好看
    #antibond_color = input("""--> Set the color of the antibonding area""")
#----------------------------------------------------------------#
    xmax_v = float(xmax_v)
    xmin_v = float(xmin_v)
    #ymax_v = float(ymax_v) #此处设置y轴范围没意义
    #ymin_v = float(ymin_v)
    font_size = int(font_size)
#----------------------------------------------------------------#
    print("--> Start drawing...")
    xlab="Energy (eV)"
    ylab="-COHP"
    #fs=15
    fz=[8,4]
    fn="COHPCAR.plot"
    savefn="COHP.png"
    #plt.rcParams['font.family']=['Times New Roman'] #有的环境没有该字体
    file=open(fn,'r+')
    lines=file.readlines()
    x=[float(lines[i].strip().split()[0])for i in range(len(lines))]
    y1=[-1*float(lines[i].strip().split()[1])for i in range(len(lines))]
    fig=plt.figure(figsize=fz)
    ax=plt.subplot(111)
    ax.plot(x,y1,label=ylab,color='black')
    #ax.legend()
    plt.ylabel(ylab, fontsize = label_size)
    plt.xlabel(xlab, fontsize = label_size)
    ax.set_xlim(xmax = xmax_v)
    ax.set_xlim(xmin = xmin_v)
    #ax.set_ylim(ymax = ymax_v)  #此处设置y轴范围没意义
    #ax.set_ylim(ymin = ymin_v)
    y2=np.array(y1)
    plt.fill_between(x,y1,where=0>y2,color='blue',alpha=.5)
    plt.fill_between(x,y1,where=0<y2,color='yellow',alpha=.7)
    resulty1 = np.min(y1)
    resulty = np.max(y1)
    plt.text(xmax_v-0.5,resulty-0.3,'ICOHP=%s'%icohp,ha='right',fontsize=font_size2)# 在图中添加文字
    plt.text(xmin_v+0.5,resulty1+0.2,'%s'%fig_name,ha='left',fontsize=font_size3)# 在图中添加文字
    plt.tick_params(labelsize=font_size)
    plt.axhline(y=0,ls="dashed",c="black")
    plt.axvline(x=0,ls=":",c="black")
    plt.savefig(savefn,format='png',bbox_inches='tight',  dpi=500)
    print("--> Done, output: COHP.png")
#----------------------------------------------------------------------------#
else:
    print("--> ICOHP = %f " % (icohp))
    print("--> Exit, you can draw a diagram based on COHPCAR.plot")
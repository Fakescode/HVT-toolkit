#!/bin/bash
# author: Hanbin_He

echo "Work is being organised..."
mkdir bandcal
cp CHGCAR bandcal
cp CONTCAR POTCAR WAVECAR bandcal
cd bandcal
mv CONTCAR POSCAR

cat > INCAR.band <<!
SYSTEM = band calcualtion    #system name

# Start parameter for this Run:
ISTART = 1      # Inital wave function: 0-new ;1-read WAVECAR file(KPOINT and number of bands should be consistent)
ICHARG = 11      # Charge: 1-read WAVECAR file;2-from atom for new calcuation;11 for band structure and DOS(selfconsistent CHGCAR file should exit) ;12 for charge density difference (Non-selfconsistent calculations for a superposition of atomic charge densities)
ISPIN = 2
ISYM=2
LREAL=.FALSE.   #.FALSE. in reciprocal;.TRUE. in real-space;  T is for opt; F is for SCF
ENCUT = 500.00 eV
ISMEAR = 0     # 0 is Gaussian smearing; ?1 is Fermi smearing;-5 is tetrahedron method (semiconductors or insulators);1 or 2 is for metal with SIGMA= 0.2
SIGMA=0.05     # Width of the smearing in ev; The number should be tested.SIGMA is useless when ISMEAR = -5
GGA = PE
# Electronic Relaxation :
ISIF=2
IALGO = 38      # SCF Algorithm: 38-Davidson which is reliable and slow ;48-RMM-DIIS which is fast; Fast-Davidson in first few steps and swtich to RMM-DIIS
NELM = 60       # SCF steps : SCF will reach convergence in 40 setp
EDIFF = 1E-05   # SCF convergence criterion: 1E-03 for rough relaxation ; 1E-05 for accurate relaxation 

# Ionic Relaxation :
IBRION = -1     # -1 is for scf calcualtion, no ionic relaxation will be done
NSW = 0         #  The number set to be zero means no ionic relaxation will be done     
LVHAR = .TRUE.  # For calculate the Work Function

# Other options
LAECHG=.TRUE.   # for Bader charge calcualtion
LORBIT=11       # for DOS and PDOS calcualtion
LELF=T
NEDOS=1000      # NEDOS specifies number of gridpoints on which the DOS is evaluated.
PREC=Accurate
#LCHARG=F       # Whether the Charge is written: T is default   There is used for accurate relaxation 
#LWAVE=F        # Whether the WAVE is written :  T is default   There is used for accurate relaxation 
!

#1D Structure    #2D Structure    #Bulk Structure
read -p "Structure type : 1.(1D) 2.(2D) 3.(Bulk) > " t
if [ $t == 1 ] ; then
echo -e "301" | vaspkit >> gkpath301.dat
mv INCAR INCAR-ref
mv INCAR.band INCAR
cp KPATH.in KPOINTS
echo "The operation is complete, you need to check the INCAR file."
elif [ $t == 2 ] ; then
echo -e "302" | vaspkit >> gkpath302.dat
mv INCAR INCAR-ref
cp KPATH.in KPOINTS
mv INCAR.band INCAR
echo "The operation is complete, you need to check the INCAR file."
elif [ $t == 3 ] ; then
echo -e "303" | vaspkit >> gkpath303.dat
mv INCAR INCAR-ref
cp KPATH.in KPOINTS
mv INCAR.band INCAR
echo "The operation is complete, you need to check the INCAR file."
else
echo "ERROR input, please restart again!"
cd ..
rm -rf bandcal
fi






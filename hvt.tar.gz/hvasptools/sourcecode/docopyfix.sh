#!/bin/bash
#Hanbin_He
#To use it:bash copyfix.sh
#POSCAR is the file to edit.   #FT is the example file .
#Used to copy the coordinate fixation information in the vasp input file POSCAR.
#Ensure that the file to be processed does not contain information about fixed coordinates.
#You need to make sure that the two files have the same coordinate order and atomic number.
#You need to make sure that the names of the two files are different.
read -p "Input file to be processed and the case file -> " pro cas
head -7 $pro > POSCAR-out
echo "Selective dynamics" >> POSCAR-out
echo "Direct" >> POSCAR-out
sed -n '9,$p' $pro > pos
cat $cas | sed -n '10,$p' | awk '{ print $4"  "$5"  "$6 }' > pos1
#---------------all2unix-------------------#
for i in `ls -l |grep -v ^d|awk '{print $9}'` ;
#for i in `ls pos*` ;
 do sed -i "s/\t/    /g" ${i} ;
 sed -i "s/\r//g"  ${i} ;
done
#------------------------------------------#
#dos2unix pos* POS* #also good
paste pos pos1 >> POSCAR-out
rm -rf pos pos1

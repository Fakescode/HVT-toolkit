#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Ref: Atkin's Physical chemistry, 10th Edition, Statistical thermodynamics: the vibrational Contribution, Page: 642
# Writen By Hanbin_He from NCEPU/ICCAS in 2023-05-06
# To use it: python dozpeTS.py
# version : 4.0
import os
import math
import sys
import pandas as pd
h_p = float(6.62606957E-34)  # J*s Plank Constant
k_b = float(1.38064852E-23)  # m²*kg*s⁻²*K⁻¹ Boltzman Constant 
R_gas = 8.3144598            # J*mol⁻¹*K⁻¹ Gas Constant 
l_s = 299792458              # light speed m * s ⁻¹
Tem = input("->Please Enter The Temperature (K): ")
Tem = float(Tem)
beta = 1/(k_b * Tem)
#1Hartree = 27.211396641308 eV
#print("+------------------------------------------------------------------------+")

with open("OUTCAR","r") as fre:
 lines = fre.readlines()
 list8 = []
 list10 = []
 freq = open("frequencies_out.txt",'w+')
 for lines in lines:
#    if "cm-1" in lines:  #Imaginary frequency is including.
    if "f  =" in lines:
#      print(lines,end="")
      freq.write(lines)
#      a = lines.split()
 freq.close()
#print(list8)
readpath='frequencies_out.txt'
writepath='frequencies.txt'
lines_seen=set()
outfile = open(writepath,'w+',encoding='utf-8')
f = open(readpath,'r',encoding='utf-8')
for line in f:
  if line not in lines_seen:
    outfile.write(line)
    lines_seen.add(line)
    a = line.split()
    b = a[7]
    c = a[9]
    list8.append(b)
    list10.append(c)
hv_sum = 0.0
for i1 in list10:
   hv_sum = float(hv_sum) + float(i1)
E_zpe = float(hv_sum) / float(2000)
EzpeH = E_zpe * 23.0605
list_nu = []

for i in list8:
   nu = float(i) * 100
   list_nu.append(nu)

list_ts = []
for nu in list_nu:
 def get_pf(nu):
   x_i = h_p * float(nu) * l_s * beta
   pf_l = x_i / (math.exp(x_i) - 1)
   pf_r = math.log(1 - math.exp(-x_i))
   pf = pf_l - pf_r
   entropy = R_gas * pf
   return entropy
 entropy = get_pf(nu)
 ts = entropy * Tem / 1000 / 96.485
 
 list_ts.append(ts)
#------------------------------------------------------#
list_H1 = []
for nu in list_nu:
 def get_pf1(nu):
#   print(nu)
   x_i = h_p * float(nu) * l_s * beta
   theta_v = x_i * Tem
   enthalpy = R_gas * theta_v * (1.0/(math.exp(theta_v/Tem)-1)) #enthalpy
   return enthalpy
 enthalpy = get_pf1(nu)
 sum_enthalpy = enthalpy/1000.0/96.485  # Ev correction to U
 list_H1.append(sum_enthalpy)
H = 0
for h in list_H1:
  H = H + h
Enthalpies = H + E_zpe
EnthalpiesH = Enthalpies * 23.0605
#------------------------------------------------------#
KbT = k_b * Tem /(1.60217733e-19)   # H=U+KbT
#print("  H=U+KbT, KbT = : %.6f eV/K" %(KbT))
#------------------------------------------------------#
TS = 0
for k in list_ts:
  TS = TS + k
S = TS / Tem
G_T = Enthalpies - TS
GH = G_T * 23.0605
SH = S * 96.4853 * 1000
TSH = TS * 96.4853 * 1000
os.remove("frequencies_out.txt")
os.remove("frequencies.txt")
#----------------------------------------------------------------------------------#
output = [ ["|  Zero-point energy E_ZPE   :",EzpeH,"kcal/mol",E_zpe,"eV"],
           ["|  Thermal correction to H(T):",EnthalpiesH,"kcal/mol",Enthalpies,"eV"],
           ["|  Thermal correction to G(T):",GH,"kcal/mol",G_T,"eV"],
           ["|  Entropy S                 :",SH,"J/(mol*K)",S,"eV/K"],
           ["|  Entropy contribution T*S  :",TSH,"J/(mol)",TS,"eV"]]
df = pd.DataFrame(output, columns = ["Item             ", "E    ", "units  ","E   ","units"])
print(df)
#print("+------------------------------------------------------------------------+")

fo = open("Thermaldata.dat",'w')
print(df,file=fo)
fo.close  # Export the  Thermal correction data to the file 'Thermaldata.dat'.

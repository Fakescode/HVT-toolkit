#!/bin/bash
echo "--> Charge-Density Difference"
echo "--> delta_rho = rho_AB - rho_A - rho_B   "
read -p "--> rho_AB = " AB
read -p "--> rho_A  = " A
read -p "--> rho_B  = " B
echo "--> Reading Structural Parameters ..."     #没啥意思，就是发个提示证明在工作而已
perl $hvtpath/bin/Tools/chgsum.pl $A $B > chg.log
echo "--> Reading Charge Density ..."
perl $hvtpath/bin/Tools/chgdiff.pl $AB CHGCAR_sum  >> chg.log
echo "--> Output: CHGCAR_diff.vasp "
rm -rf chg.log CHGCAR_sum
mv CHGCAR_diff CHGCAR_diff.vasp







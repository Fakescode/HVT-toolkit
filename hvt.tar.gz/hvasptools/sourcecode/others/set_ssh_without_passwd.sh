#!bin/bash
#author: Hanbin He
#hanbin_he@ncepu.edu.cn
echo "keep tapping Enter until the next prompt appears"
ssh-keygen
stty erase ^h
stty erase ^H
stty erase ^?
read -p "Enter the username and the serverid" > usr serverid
#ssh-copy-id -i ~/.ssh/id_rsa.pub usr@serverid
ssh-copy-id -i ~/.ssh/id_rsa.pub $usr@"$serverid"

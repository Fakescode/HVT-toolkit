#!/bin/bash
# author: Hanbin_He .
# version:1.0 .
# To use it : bash ***.sh ***.zip.
# Autonomous decompression scripts.
# The decompression software needs to be installed in advance. 
# Used to help unzip (unzip command), does not involve unzipping the source code. 
case $1 in
        *.zip)
        unzip $1 $Temp_Dir;;
        *.rar)
        unrar $1 $Temp_Dir;;
		*.tar)
		tar -xf $1 $Temp_Dir;;
		*.tar.gz)
		tar -zxvf $1 $Temp_Dir;;
		*.gz)
		gunzip $1 $Temp_Dir;;
		*.bz2)
		bunzip2 $1 $Temp_Dir;;
		*.tar.bz2)
		tar -jxvf $1 $Temp_Dir;;
		*.7z)
		7z x $1 $Temp_Dir;;
		*.tar.xz)
		tar -xvjf $1 $Temp_Dir;;
		*.Z)
		uncompress $1 $Temp_Dir;;
		*.xz)
		xz -dk $1 $Temp_Dir;;
		*.tgz)
		tar -zxvf $1 $Temp_Dir;;
	        *.tar)
		tar -xvf $Temp_Dir;;
        *)
		
        exit 1;;
esac








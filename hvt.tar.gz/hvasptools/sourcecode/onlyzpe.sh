#!/bin/bash
#author: Hanbin He
#hanbin_he@ncepu.edu.cn
#To use it : bash calzpe.sh
#version: 1.0
#hv_sum=$(grep 'cm-1' OUTCAR | awk '{print $10}' | paste -sd+ | bc)
#hv_sum=$(grep 'f  =' OUTCAR | awk '{print $10}' | paste -sd+ | bc)
hv_sum=$(grep 'f  =' OUTCAR | sort -u | awk '{print $10}' | paste -sd+ | bc)
zpe=$(echo "scale = 6; $hv_sum/2000" | bc | awk '{printf "%.5f", $0}')
echo "Zero-point energy E_ZPE = $zpe eV"
#echo "scale = 6; $hv_sum/2000" | bc

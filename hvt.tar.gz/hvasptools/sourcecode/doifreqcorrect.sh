#!/bin/bash
#author: Hanbin He
#hanbin_he@ncepu.edu.cn
#To use it : bash freqcorrect.sh
#version: 2.0
#2023.04.14
#***************************************************************************************************************************#
#Normally the frequencies of the non-fixed atoms are counted in OUTCAR. If 4 non-fixed atoms are present, 12 frequencies (translational, rotational, vibrational) are output in OUCAR and arranged in descending order of frequency. Setting the correction factor to c, one can empirically add dx*c to each of the X columns of the first imaginary frequency that appears to obtain the new coordinate X. Similarly, Y + dy*c gives the new Y value and Z + dz*c gives the new Z value. The new X, Y, Z denote the corrected structural coordinates, put in POSCAR, and then calculate the frequencies it is possible that the imaginary frequencies will disappear. Several points need to be noted:
#1) The correction factor c should preferably be within 0.5, and the larger the imaginary frequency, the larger the value should be set. The reason why luck is needed is that it is entirely empirical (if the location of point C can be obtained accurately by false frequency correction, there is no need to go to great lengths to do the search)
#2) Since the imaginary frequency correction process yields new coordinates for the structure, a static self-consistency should be done using coordinates with and only one imaginary frequency as the saddle point energy.
#3) This correction method is not applicable to corrections where the imaginary frequency is too large (>200 cm-1).
#***************************************************************************************************************************#
#The script needs to be used within the frequency calculation folder to generate POSCAR-out.
#This script is for the ding group only.
#This script is an empirical setting and does not guarantee that it will work.
#***************************************************************************************************************************#
#echo -e "\e[33m+-----------------------------------------------------------+\e[0m"
#echo -e "\e[33m|        Script used to correct Virtual frequency           |\e[0m"
#echo -e "\e[33m+-----------------------------------------------------------+\e[0m"
echo -e "1.Refresh and generate a new POSCAR...                    "
m=$(grep "00E+00" CONTCAR)
n=$(grep "NaN" CONTCAR)
if [ ! -n "$m" ]; then
   if [ ! -n "$n" ]; then
      cp CONTCAR POSCAR-log
      sed '/^ *$/d' POSCAR-log > POSCAR-new
   else
      grep -v "NaN" CONTCAR > POSCAR-log
      sed '/^ *$/d' POSCAR-log > POSCAR-new
   fi
else
  grep -v "0000E+00" CONTCAR > POSCAR-log
  sed '/^ *$/d' POSCAR-log > POSCAR-new
fi
rm -rf POSCAR-log
echo -e "2.Deal dxdydz obtained from freq... "
#***************************************************************************************************************************#
#grep f/i OUTCAR | sort -u | awk 'BEGIN{ max = 0} {if ($9 > max) max = $9; fi} END{printf "-->3.The Max energy of the imaginary vibrational mode = %f\n",max}'
#em=$(grep f/i OUTCAR | sort -u | awk 'BEGIN{ max = 0} {if ($9 > max) max = $9; fi} END{printf "%f\n",max}')
#***************************************************************************************************************************#
em=$(grep f/i OUTCAR | sort -u | head -1 | awk '{print $9}')
lineb=$(grep f/i OUTCAR | sort -u | head -1 | awk '{print $1}')
lines=$(($lineb+1 ))
#echo "line stop = $lines"
m1=$(grep "$lines f/i" OUTCAR | sort -u | head -1 | awk '{print $9}' )
#echo "energy of stop line = $m1"
echo "3.The energy of the first imaginary vibrational mode = $em"
echo "4.The energy of the second imaginary vibrational mode = $m1"
m=$(grep $em OUTCAR |sort -u | awk '{print $1}' | tail -1)
#echo $m
sta=$(grep -n "$m f" OUTCAR | awk '{print $1}' |tail -1|tr -d ':')
#echo $sta
#sto=$(grep -n "Finite differences POTIM=" OUTCAR | awk '{print $1}' |tail -1|tr -d ':' )
#sto=$(grep -n "$m1 f/i" OUTCAR | awk '{print $1}' |tail -1|tr -d ':')
ww=$(grep -n "$lines f/i" OUTCAR | awk '{print $1}' |tail -1|tr -d ':')
#echo "***************************************"
#grep -n "$lines f" OUTCAR | awk '{print $1}' |tail -1|tr -d ':'
#echo "***************************************"
#echo "stop line: $ww"
f="$ww"p
#echo "finaly line is $f"
sed -n $sta,$f OUTCAR > log
cp log log2
sed -i '1,2d' log
sed -i '$d' log
sed -i '$d' log2
#cat log | awk '{print $4" "$5" "$6}' > log1
#cat log | awk '{print $4" "$5" "$6}' 
#cp log log1
awk '{ $1=null;$2=null;$3=null;print }' log > log1
#rm -rf log

judge1=$( sed -n 8p POSCAR-new )
judge=$(echo ${judge1:0:1})
#echo $judge
if [ $judge == S ] ; then
echo "5.Detected Selective dynamics..."
sel=1
#*******************************Delete atomic fixation-related information*********************************************#
head -9 POSCAR-new > POSCARout
grep -v "0000E+00" POSCAR-new >> pos
cat pos | sed -n '10,$p' | awk '{ print $1"  "$2"  "$3 }' >> POSCARout
rm -rf pos
sed -i '8d' POSCARout #delect the line of 'Selective dynamics'
mv POSCAR-new POSCAR-FT
#**********************************************************************************************************************#
else
echo "5.No selective atoms within POSCAR..."
sel=0
fi
#**********************************************************************************************************************#
atomnum=$(cat log | wc -l)
#echo "-->6.Number of atoms : $atomnum"
echo "6.Generate new xyz, please wait..."
#***************Do the calculate : x+dx y+dy z+dz ; export the result to xyz.log****************************************#
read -p "7.Please input the correction facter(0-0.5) :  " n

rm -rf xyz.log #Delect the former result.
atomnum=$(cat log | wc -l)
#echo "Number of atoms : $atomnum"
#str=""
#arr=("|" "/" "-" "\\")

for ((i=1;i<$atomnum;i++));
do
#echo $i
#sed -n "$i"p log
x=$(sed -n "$i"p log | awk '{print $1}')
dx=$(sed -n "$i"p log | awk '{print $4}')
dxx=$(echo "scale=4;$n*$dx" | bc)
y=$(sed -n "$i"p log | awk '{print $2}')
dy=$(sed -n "$i"p log | awk '{print $5}')
dyy=$(echo "scale=4;$n*$dy" | bc)
z=$(sed -n "$i"p log | awk '{print $3}')
dz=$(sed -n "$i"p log | awk '{print $6}')
dzz=$(echo "scale=4;$n*$dz" | bc)
#x1=$((${x//$'\r'}+${dx//$s'\r'}))
#let x1=$x+$dx #echo $[$x+$dx] #echo $x1
x1=$(echo "scale=4;$x+$dxx" | bc)
#echo $x1
x2=$(printf "%.8f" "$x1")
#echo $x2
y1=$(echo "scale=4;$y+$dyy" | bc)
y2=$(printf "%.8f" "$y1")
z1=$(echo "scale=4;$z+$dzz" | bc)
z2=$(printf "%.8f" "$z1")
#echo "$x2 $y2 $z2" #notice! this line is the test program! It is very good!
echo "$x2  $y2  $z2" >> xyz.log

#  let index=i%4 #  let indexcolor=i%8 #  let color=30+indexcolor
  let NUmbER=$i
#  printf "\e[0;$color;1m[%-20s][%d%%]%c\r" "$str" "$NUmbER" "${arr[$index]}"   #  printf "\e[0;1m[%-20s][%d%%]%c\r" "$str" "$NUmbER" "${arr[$index]}"   #  z2=$(echo "scale=4;18/174" | bc)
  #printf "\e[ P8.Processing atom : [%-3s]/[$atomnum]\r" "$NUmbER"
  printf "\e[ P8.Processing atom : [%-3s]-[step]\r" "$NUmbER"
  done
    printf "\n"
#****************Get the deadline and FT-information from old POSCAR, and add all to POSCAR-out*************************#
if [ $sel == 1 ] ; then
rm -rf cartesian.log
atomnum=$(cat log | wc -l)
#echo $atomnum
at1=$(($atomnum+1))
#echo $at1
head -8 POSCAR-FT > POSCAR-out
echo "Cartesian" >> POSCAR-out
for ((i=1;i<$at1;i++));
do
     line9=$(($i+9))
     #echo "atom in POSCAR is $line9 , in log is $i"
     x3=$(sed -n "$i"p xyz.log )
     x4=$(sed -n "$line9"p POSCAR-FT | awk '{print $4" "$5" "$6}')
     #echo $x3 #echo $x4  #echo $x3 $x4
     echo $x3 $x4 >> cartesian.log
     #echo "----------------------------------"
     let NUmbER=$i
     #  printf "\e[0;$color;1m[%-20s][%d%%]%c\r" "$str" "$NUmbER" "${arr[$index]}"
     #  printf "\e[0;1m[%-20s][%d%%]%c\r" "$str" "$NUmbER" "${arr[$index]}"
     #  z2=$(echo "scale=4;18/174" | bc)
     printf "\e[ P9.Processing POSCAR : [%-3s]/[$atomnum]\r" "$NUmbER"
done
      printf "\n"
      #----------------------------------------------------------------------#
      file=./cartesian.log
      while read line
      do
      #printf "%12s %12s %12s %8s %8s %8s\n" ${line}
      printf "%12s %12s %12s %4s %4s %4s\n" ${line} >> Cartesian1.log
      printf "%12s %12s %12s %4s %4s %4s\n" ${line} >> POSCAR-out
      done < ${file}
      rm -rf cartesian.log
else
      rm -rf cartesian.log
      atomnum=$(cat log | wc -l)
      #echo $atomnum
      at1=$(($atomnum+1))
      #echo $at1
      head -7 POSCAR-FT > POSCAR-out
      echo "Cartesian" >> POSCAR-out
for ((i=1;i<$at1;i++));
do
      line8=$(($i+8))
      #echo "atom in POSCAR is $line8 , in log is $i"
      x3=$(sed -n "$i"p xyz.log )
     # x4=$(sed -n "$line8"p POSCAR-FT | awk '{print $4" "$5" "$6}')
      #echo $x3 #echo $x4  #echo $x3 $x4
      echo $x3 >> cartesian.log
      let NUmbER=$i
      printf "\e[ P9.Processing POSCAR : [%-3s]/[$atomnum]\r" "$NUmbER"
done
   printf "\n"
#----------------------------------------------------------------------#
file=./cartesian.log
   while read line
do
 printf "%12s %12s %12s\n" ${line} >> Cartesian1.log
 printf "%12s %12s %12s\n" ${line} >> POSCAR-out
 done < ${file}
 rm -rf cartesian.log
fi
#***********************************************************************************************************************#
rm -rf log log1 log2 Cartesian1.log POSCARout xyz.log
mv POSCAR-out POSCAR-out1
sed '/^ *$/d' POSCAR-out1 > POSCAR-out
rm -rf POSCAR-out1
echo -e "10.Operation complete, output file: POSCAR-out "
echo ">>Prayers and good luck for the next calculation<<"

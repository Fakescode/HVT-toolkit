#!/bin/bash
#Used in ci-neb to get the transition state structure and then do freq and then generate improved dimer calculations(idm) input file POSCAR in freq folder
#author: Hanbin He
#2023.04.01
#For this script to work, the folder needs to contain the OUTCAR and CONTCAR calculated by freq, or the CONTCAR of the transition state calculated by ci-neb
#This script is for use by the ding group only.
echo -e "\e[33m+-----------------------------------------------------------+\e[0m"
echo -e "\e[33m|          Script used to generate POSCAR for idm           |\e[0m"
echo -e "\e[33m+-----------------------------------------------------------+\e[0m"
echo -e "-->1.Refresh and generate POSCAR-dimer...                    "
m=$(grep "00E+00" CONTCAR)
n=$(grep "NaN" CONTCAR)
if [ ! -n "$m" ]; then
   if [ ! -n "$n" ]; then
      cp CONTCAR POSCAR-dim
      sed '/^ *$/d' POSCAR-dim > POSCAR-dimer
   else
      grep -v "NaN" CONTCAR > POSCAR-dim
#      sed -i '$d' POSCAR-dimer
      sed '/^ *$/d' POSCAR-dim > POSCAR-dimer
   fi
else
  grep -v "0000E+00" CONTCAR > POSCAR-dim
#  sed -i '$d' POSCAR-dimer
  sed '/^ *$/d' POSCAR-dim > POSCAR-dimer
fi
rm -rf POSCAR-dim
echo "! Dimer Axis Block" >> POSCAR-dimer
#echo -e "+-----------------------------------------------------------+"
#--------------------------------------------------#
echo -e "-->2.Add dxdydz obtained from freq to POSCAR-dimer...        "
######################################################################################
grep f/i OUTCAR | sort -u | awk 'BEGIN{ max = 0} {if ($9 > max) max = $9; fi} END{printf "-->3.The Max energy of the imaginary vibrational mode = %f\n",max}'
em=$(grep f/i OUTCAR | sort -u | awk 'BEGIN{ max = 0} {if ($9 > max) max = $9; fi} END{printf "%f\n",max}')
#echo $em
#grep "f/i" OUTCAR | sort -u | awk 'BEGIN{ max = 0} {if ($9 > max) max = $9; fi} END{printf "%f\n",max}'
m=$(grep $em OUTCAR |sort -u | awk '{print $1}' | tail -1)
#####################################################################################
#m=$(grep cm-1 OUTCAR | sort -u | awk '{print $1}' | tail -1) #there is a lot of problem,so rewrite it, Give up it
#echo "m : $m "
sta=$(grep -n "$m f" OUTCAR | awk '{print $1}' |tail -1|tr -d ':')
#echo "sta = $sta"
sto=$(grep -n "Finite differences POTIM=" OUTCAR | awk '{print $1}' |tail -1|tr -d ':' )
#echo "sto = $sto"
f="$sto"p
#echo $f
sed -n $sta,$f OUTCAR > log
sed -i '1,2d' log
sed -i '$d' log
cat log | awk '{print $4" "$5" "$6}' >> POSCAR-dimer
rm -rf log
#echo -e "+-----------------------------------------------------------+"
echo -e "-->4.Operation complete, output file: POSCAR-dimer             "
#echo -e "\e[33m+-----------------------------------------------------------+\e[0m"

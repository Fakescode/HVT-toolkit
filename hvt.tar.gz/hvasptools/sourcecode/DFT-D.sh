#!/bin/bash

# author: Hanbin_He
# version:3.0
# DFT-D method Builder
# 2022.07.12
# To use it : bash DFT-D2.sh
# hanbin_he@ncepu.edu.cn
# 该脚本中有很多没用的注释的部分，使用的同学如果有兴趣可以随意删除
# 更新：加入了安装设置
# 声明：免费使用该脚本的条件是“需保证当你在任何QQ或者微信群里看到作者的求助信息时，能帮作者买碗泡面充饥”

#echo -e " "
#echo -e "\e[36m                        ********************************\n                        *    DFT-D method Builder      *   \n                        *       auther:Hanbin          *\n                        *        version:3.0           *\n                        ********************************\e[0m"
#echo -e "\n"
#echo -e "\e[32m通过修改交换关联项考虑范德华修正，即vdW-DF,官网描述如下：\nIVDW tag controls whether vdW corrections are calculated or not.\nIf they are calculated IVDW controls how they are calculated.\nThe choice of vdW method is controlled via the following tags:\e[0m "
#echo -e "\n"

#echo -e "\e[32mIVDW=0 no correction\nIVDW=1|10 DFT-D2 method of Grimme (available as of VASP.5.2.11)\nIVDW=11 zero damping DFT-D3 method of Grimme (available as of VASP.5.3.4)\nIVDW=12 DFT-D3 method with Becke-Jonson damping (available as of VASP.5.3.4)\nIVDW=13 DFT-D4 method (available as of VASP.6.2 as external package)\nIVDW=2|20 Tkatchenko-Scheffler method (available as of VASP.5.3.3)\nIVDW=21 Tkatchenko-Scheffler method with iterative Hirshfeld partitioning (available as of VASP.5.3.5)\nIVDW=202 Many-body dispersion energy method (MBD@rSC) (available as of VASP.5.4.1)\nIVDW=4 dDsC dispersion correction method (available as of VASP.5.4.1)\e[0m "
#echo -e "\n"
#echo -e "\e[32mAll methods listed above add vdW correction to potential energy, interatomic forces, as well as stress tensor and hence simulations such as atomic and lattice relaxations, molecular dynamics, and vibrational analysis (via finite differences) can be performed. Note, however, that these correction schemes are currently not available for calculations based on density functional perturbation theory.\e[0m"
#echo -e "\e[32mThe parameter LVDW used in previous versions of VASP (5.2.11 and later) to activate DFT-D2 method is now obsolete. If LVDW=.TRUE. is defined, IVDW is automatically set to 1 (unless IVDW is specified in INCAR)\e[0m"

echo -e "\e[33m*********************************************************************************\e[0m"
echo -e "\e[33m*Enter the serial number of the following options to select the method you need:*\e[0m"

echo -e "\e[34m*  1.DFT-D2 method of Grimme                                                    *\n*  2.DFT-D3 method of Grimme                                                    *\n*  3.DFT-D3 method with Becke-Jonson damping                                    *\n*  4.DFT-D4 method                                                              *\n*  5.Tkatchenko-Scheffler method                                                *\n*  6.Tkatchenko-Scheffler method with iterative Hirshfeld partitioning          *\n*  7.Many-body dispersion energy method                                         *\n*  8.dDsC dispersion correction method                                          *\n*  9.Install DFT-D.sh                                                           *\n*  You can enter any other character to exit                                    *\e[0m"
echo -e "\e[33m*********************************************************************************\e[0m"

stty erase ^h
stty erase ^?
stty erase ^H
read -p "Enter your select number > " n
#echo "$n was input"
if [ $n == 1 ] ; then
    echo "DFT-D2 method of Grimme"
#!/bin/bash
# author: hanbin
# version:1.0
# DFT-D2 method Builder
# 2022.07.12
# To use it : bash DFT-D2.sh
# hanbin_he@ncepu.edu.cn 

echo LVDW = .TRUE. >> INCAR
echo VDW_RADIUS = 30.0 >> INCAR
echo VDW_SCALING = 0.75 >> INCAR
echo VDW_D = 20.0 >> INCAR

echo -e " "
echo -e "\e[36m                        ********************************\n                        *   DFT-D2 method Builder      *   \n                        *       auther:Hanbin          *\n                        *        version:3.0           *\n                        ********************************\e[0m"

#echo "                        ********************************"
#echo "                        *    DFT-D2 method Builder     *"
#echo "                        *       auther:Hanbin          *"
#echo "                        *        version:3.0           *"
#echo "                        ********************************"
echo -e "\n"
echo -e "\e[34mVDW_C6和VDW_R0的默认值仅针对元素周期表的前五行（即 H-Xe）中的元素定义。\n如果系统包含其他元素，用户必须在INCAR中定义这些参数。\n控制阻尼功能的参数（VDW_S6、VDW_SR、VDW_D）的默认值仅适用于 PBE 功能。\n如果在 DFT+D2 计算中使用 PBE 以外的函数，则必须在 INCAR 中定义 VDW_S6\n使用 PBE 以外的函数，也可以定义VASP.5.3.4 之前版本中的VDW_SCALING。\n从 VASP.5.3.4 开始， VDW_RADIUS的默认值已从 30 增加到 50埃。\e[0m "
echo -e " "

elements=$(sed -n 6p POSCAR| tr -d "\r")
echo -e "The following elements were found in POSCAR：\n $elements"

var=$(echo $elements)
set $var
#echo $i | xargs -n1
#echo $2 | xargs -n2
#echo $3 | xargs -n3

for i in $var
do

if [ $i == H ];then
#	echo -e "VDW_C6 = 0.14\nVDW_R0 = 1.001"
	echo VDW_C6 = 0.14 >> VDWC6.txt
	echo VDW_R0 = 1.001 >> VDWR0.txt
elif [ $i == He ];then
 #      echo -e "VDW_C6 = 0.08\nVDW_R0 = 1.012"
        echo VDW_C6 = 0.08 >> VDWC6.txt
        echo VDW_R0 = 1.012 >> VDWR0.txt
elif [ $i == Li ];then
  #      echo -e "VDW_C6 = 1.61\nVDW_R0 = 0.825"
        echo VDW_C6 = 1.61 >> VDWC6.txt
        echo VDW_R0 = 0.825 >> VDWR0.txt
elif [ $i == Be ];then
     #   echo -e "VDW_C6 = 1.61\nVDW_R0 = 1.408"
        echo VDW_C6 = 1.61 >> VDWC6.txt
        echo VDW_R0 = 1.408 >> VDWR0.txt
elif [ $i == B ];then
  #      echo -e "VDW_C6 = 3.13\nVDW_R0 = 1.485"
        echo VDW_C6 = 3.13 >> VDWC6.txt
        echo VDW_R0 = 1.485 >> VDWR0.txt
elif [ $i == C ];then
 #       echo -e "VDW_C6 = 1.75\nVDW_R0 = 1.452"
        echo VDW_C6 = 1.75 >> VDWC6.txt
        echo VDW_R0 = 1.452 >> VDWR0.txt
elif [ $i == N ];then
   #     echo -e "VDW_C6 = 1.23\nVDW_R0 = 1.397"
        echo VDW_C6 = 1.23 >> VDWC6.txt
        echo VDW_R0 = 1.397 >> VDWR0.txt
elif [ $i == O ];then
  #      echo -e "VDW_C6 = 0.70\nVDW_R0 = 1.342"
        echo VDW_C6 = 0.70 >> VDWC6.txt
        echo VDW_R0 = 1.342 >> VDWR0.txt
elif [ $i == F ];then
  #      echo -e "VDW_C6 = 0.75\nVDW_R0 = 1.287"
        echo VDW_C6 = 0.75 >> VDWC6.txt
        echo VDW_R0 = 1.287 >> VDWR0.txt
elif [ $i == Ne ];then
  #      echo -e "VDW_C6 = 0.63\nVDW_R0 = 1.243"
        echo VDW_C6 = 0.63 >> VDWC6.txt
        echo VDW_R0 = 1.243 >> VDWR0.txt
elif [ $i == Na ];then
  #      echo -e "VDW_C6 = 5.71\nVDW_R0 = 1.144"
        echo VDW_C6 = 5.71 >> VDWC6.txt
        echo VDW_R0 = 1.144 >> VDWR0.txt
elif [ $i == Mg ];then
   #     echo -e "VDW_C6 = 5.71\nVDW_R0 = 1.364"
        echo VDW_C6 = 5.71 >> VDWC6.txt
        echo VDW_R0 = 1.364 >> VDWR0.txt
elif [ $i == Al ];then
   #     echo -e "VDW_C6 = 10.79\nVDW_R0 = 1.716"
        echo VDW_C6 = 10.79 >> VDWC6.txt
        echo VDW_R0 = 1.716 >> VDWR0.txt
elif [ $i == Si ];then
   #     echo -e "VDW_C6 = 9.23\nVDW_R0 = 1.716"
        echo VDW_C6 = 9.23 >> VDWC6.txt
        echo VDW_R0 = 1.716 >> VDWR0.txt
elif [ $i == P ];then
   #     echo -e "VDW_C6 = 7.84\nVDW_R0 = 1.705"
        echo VDW_C6 = 7.84 >> VDWC6.txt
        echo VDW_R0 = 1.705 >> VDWR0.txt
elif [ $i == S ];then
    #    echo -e "VDW_C6 = 5.57\nVDW_R0 = 1.683"
        echo VDW_C6 = 5.57 >> VDWC6.txt
        echo VDW_R0 = 1.683 >> VDWR0.txt
elif [ $i == Cl ];then
   #     echo -e "VDW_C6 = 5.07\nVDW_R0 = 1.639"
        echo VDW_C6 = 5.07 >> VDWC6.txt
        echo VDW_R0 = 1.639 >> VDWR0.txt
elif [ $i == Ar ];then
  #      echo -e "VDW_C6 = 4.61\nVDW_R0 = 1.595"
        echo VDW_C6 = 4.61 >> VDWC6.txt
        echo VDW_R0 = 1.595 >> VDWR0.txt
elif [ $i == K ];then
   #     echo -e "VDW_C6 = 10.80\nVDW_R0 = 1.485"
        echo VDW_C6 = 10.80 >> VDWC6.txt
        echo VDW_R0 = 1.485 >> VDWR0.txt
elif [ $i == Ca ];then
    #    echo -e "VDW_C6 = 10.80\nVDW_R0 = 1.474"
        echo VDW_C6 = 10.80 >> VDWC6.txt
        echo VDW_R0 = 1.474 >> VDWR0.txt
elif [ $i == Sc ] || [ $i == Ti ] || [ $i == V ] || [ $i == Cr ] || [ $i == Mn ] || [ $i == Fe ] || [ $i == Co ] || [ $i == Ni ] || [ $i == Cu ] || [ $i == Zn ];then
     #   echo -e "VDW_C6 = 10.8\nVDW_R0 = 1.562"
        echo VDW_C6 = 10.8 >> VDWC6.txt
        echo VDW_R0 = 1.562 >> VDWR0.txt
elif [ $i == Ga ];then
    #    echo -e "VDW_C6 = 16.99\nVDW_R0 = 1.650"
        echo VDW_C6 = 16.99 >> VDWC6.txt
        echo VDW_R0 = 1.650 >> VDWR0.txt
elif [ $i == Ge ];then
   #     echo -e "VDW_C6 = 17.10\nVDW_R0 = 1.727"
        echo VDW_C6 = 17.10 >> VDWC6.txt
        echo VDW_R0 = 1.727 >> VDWR0.txt
elif [ $i == As ];then
    #    echo -e "VDW_C6 = 16.37\nVDW_R0 = 1.760"
        echo VDW_C6 = 16.37 >> VDWC6.txt
        echo VDW_R0 = 1.760 >> VDWR0.txt
elif [ $i == Se ];then
   #     echo -e "VDW_C6 = 12.64\nVDW_R0 = 1.771"
        echo VDW_C6 = 12.64 >> VDWC6.txt
        echo VDW_R0 = 1.771 >> VDWR0.txt
elif [ $i == Br ];then
   #     echo -e "VDW_C6 = 12.47\nVDW_R0 = 1.749"
        echo VDW_C6 = 12.47 >> VDWC6.txt
        echo VDW_R0 = 1.749 >> VDWR0.txt
elif [ $i == Kr ];then
  #      echo -e "VDW_C6 = 12.01\nVDW_R0 = 1.727"
        echo VDW_C6 = 12.01 >> VDWC6.txt
        echo VDW_R0 = 1.727 >> VDWR0.txt
elif [ $i == Rb ];then
  #      echo -e "VDW_C6 = 24.67\nVDW_R0 = 1.628"
        echo VDW_C6 = 24.67 >> VDWC6.txt
        echo VDW_R0 = 1.628 >> VDWR0.txt
elif [ $i == Sr ];then
  #      echo -e "VDW_C6 = 24.67\nVDW_R0 = 1.606"
        echo VDW_C6 = 24.67 >> VDWC6.txt
        echo VDW_R0 = 1.606 >> VDWR0.txt
elif [ $i == Y ] || [ $i == Zr ] || [ $i == Nb ] || [ $i == Mo ] || [ $i == Tc ] || [ $i == Ru ] || [ $i == Rh ] || [ $i == Pd ] || [ $i == Ag ] || [ $i == Cd ];then
  #      echo -e "VDW_C6 = 24.67\nVDW_R0 = 1.639"
        echo VDW_C6 = 24.67 >> VDWC6.txt
        echo VDW_R0 = 1.639 >> VDWR0.txt
elif [ $i == In ];then
  #      echo -e "VDW_C6 = 37.32\nVDW_R0 = 1.672"
        echo VDW_C6 = 37.32 >> VDWC6.txt
        echo VDW_R0 = 1.672 >> VDWR0.txt
elif [ $i == Sn ];then
 #       echo -e "VDW_C6 = 38.71\nVDW_R0 = 1.804"
        echo VDW_C6 = 38.71 >> VDWC6.txt
        echo VDW_R0 = 1.804 >> VDWR0.txt
elif [ $i == Sb ];then
 #       echo -e "VDW_C6 = 38.44\nVDW_R0 = 1.881"
        echo VDW_C6 = 38.44 >> VDWC6.txt
        echo VDW_R0 = 1.881 >> VDWR0.txt
elif [ $i == Te ];then
   #     echo -e "VDW_C6 = 31.74\nVDW_R0 = 1.892"
        echo VDW_C6 = 31.74 >> VDWC6.txt
        echo VDW_R0 = 1.892 >> VDWR0.txt
elif [ $i == I ];then
   #     echo -e "VDW_C6 = 31.50\nVDW_R0 = 1.892"
        echo VDW_C6 = 31.50 >> VDWC6.txt
        echo VDW_R0 = 1.892 >> VDWR0.txt
elif [ $i == Xe ] || [ $i == X ];then
   #     echo -e "VDW_C6 = 29.99\nVDW_R0 = 1.881"
        echo VDW_C6 = 29.99 >> VDWC6.txt
        echo VDW_R0 = 1.881 >> VDWR0.txt
elif [ $i == Cs ];then
  #      echo -e "VDW_C6 = 315.275\nVDW_R0 = 1.802"
        echo VDW_C6 = 315.275 >> VDWC6.txt
        echo VDW_R0 = 1.802 >> VDWR0.txt
elif [ $i == Ba ];then
   #     echo -e "VDW_C6 = 226.994\nVDW_R0 = 1.762"
        echo VDW_C6 = 226.994 >> VDWC6.txt
        echo VDW_R0 = 1.762 >> VDWR0.txt
elif [ $i == La ];then
  #      echo -e "VDW_C6 = 176.252\nVDW_R0 = 1.720"
        echo VDW_C6 = 176.252 >> VDWC6.txt
        echo VDW_R0 = 1.720 >> VDWR0.txt
elif [ $i == Hf ];then
    #    echo -e "VDW_C6 =105.112\nVDW_R0 = 1.788"
        echo VDW_C6 = 105.112 >> VDWC6.txt
        echo VDW_R0 = 1.788 >> VDWR0.txt
elif [ $i == Ta ] || [ $i == W ] || [ $i == Re ] || [ $i == Os ] || [ $i == Ir ] || [ $i == Pt ] || [ $i == Au ];then
   #     echo -e "VDW_C6 = 81.24\nVDW_R0 = 1.772"
        echo VDW_C6 = 81.24 >> VDWC6.txt
        echo VDW_R0 = 1.772 >> VDWR0.txt
elif [ $i == Hg ];then
   #     echo -e "VDW_C6 = 57.364\nVDW_R0 = 1.758"
        echo VDW_C6 = 57.364 >> VDWC6.txt
        echo VDW_R0 = 1.758 >> VDWR0.txt
elif [ $i == Tl ];then
   #     echo -e "VDW_C6 = 57.254\nVDW_R0 = 1.989"
        echo VDW_C6 = 57.254 >> VDWC6.txt
        echo VDW_R0 = 1.989 >> VDWR0.txt
elif [ $i == Pb ];then
   #     echo -e "VDW_C6 = 63.162\nVDW_R0 = 1.944"
        echo VDW_C6 = 63.162 >> VDWC6.txt
        echo VDW_R0 = 1.944 >> VDWR0.txt
elif [ $i == Bi ];then
    #    echo -e "VDW_C6 = 63.540\nVDW_R0 = 1.898"
        echo VDW_C6 = 63.540 >> VDWC6.txt
        echo VDW_R0 = 1.898 >> VDWR0.txt
elif [ $i == Po ];then
   #     echo -e "VDW_C6 = 55.283\nVDW_R0 = 2.005"
        echo VDW_C6 = 55.283 >> VDWC6.txt
        echo VDW_R0 = 2.005 >> VDWR0.txt
elif [ $i == At ];then
   #     echo -e "VDW_C6 = 57.171\nVDW_R0 = 1.991"
        echo VDW_C6 = 57.171 >> VDWC6.txt
        echo VDW_R0 = 1.991 >> VDWR0.txt
elif [ $i == Rn ];then
 #       echo -e "VDW_C6 = 56.64\nVDW_R0 = 1.924"
        echo VDW_C6 = 56.64 >> VDWC6.txt
        echo VDW_R0 = 1.924 >> VDWR0.txt
elif [ $i == Ce ] || [ $i == Pr ] || [ $i == Nd ] || [ $i == Pm ] || [ $i == Sm ] || [ $i == Eu ] || [ $i == Gd ] || [ $i == Tb ] || [ $i == Dy ] || [ $i == Ho ] || [ $i == Er ] || [ $i == Tm ] || [ $i == Yb ] || [ $i == Lu ];then
   #     echo -e "VDW_C6 = 140.68\nVDW_R0 = 1.753"
        echo VDW_C6 = 140.68 >> VDWC6.txt
        echo VDW_R0 = 1.753 >> VDWR0.txt
else
        echo "No such element in our library, DFT-D3 methods is recommend"
fi
done
# 将C6值输出到屏幕上
echo " "
echo -e "\e[33mThe values of C6 are:\e[0m"
echo -e " "
echo -n "VDW_C6 = "
cat VDWC6.txt | cut -d' ' -f3 | while read line; do echo -n "${line} "; done
echo -e ""
# 将R0值输出到屏幕上
echo -e "\n"
echo -e "\e[33mThe values of R0 are:\e[0m"
echo -e " "
echo -n "VDW_R0 = "
cat VDWR0.txt | cut -d' ' -f3 | while read line; do echo -n "${line} "; done
echo -e "\n"


#将结果输入到INCAR里边
#echo " " >> INCAR
#echo -e "\e[33mThe values of C6 are:\e[0m" >> INCAR
echo -e " " >> INCAR
echo -n "VDW_C6 = " >> INCAR
cat VDWC6.txt | cut -d' ' -f3 | while read line; do echo -n "${line} " >> INCAR; done
#echo -e "" >> INCAR
#echo -e "\e[33mThe values of R0 are:\e[0m" >> INCAR
echo -e " " >>INCAR
echo -n "VDW_R0 = " >> INCAR
cat VDWR0.txt | cut -d' ' -f3 | while read line; do echo -n "${line} " >> INCAR; done
echo -e " " >> INCAR
# 这里计划加入一个检查INCAR里边有没有写入DFT-D2的过程


echo -e "\e[36mAll values have been entered into INCAR \e[0m "
echo -e "\n"

rm -rf VDWC6.txt
rm -rf VDWR0.txt

#####################################################################################################
#DFT-D2程序到此结束
	
elif [ $n == 2 ] ; then
	echo -e "\e[33m                         DFT-D3 method of Grimme                            \e[0m"
	echo "IVDW = 11" >> INCAR
elif [ $n == 3 ] ; then
	echo -e "\e[33m                 DFT-D3 method with Becke-Jonson damping                    \e[0m"
	echo "IVDW = 12" >> INCAR
elif [ $n == 4 ] ; then
	echo -e "\e[33m                             DFT-D4 method                                  \e[0m"
	echo "IVDW = 13" >> INCAR
elif [ $n == 5 ] ; then
	echo -e "\e[33m                      Tkatchenko-Scheffler method                           \e[0m"
	echo "IVDW = 2|20" >> INCAR
elif [ $n == 6 ] ; then
	echo -e "\e[33m     Tkatchenko-Scheffler method with iterative Hirshfeld partitioning      \e[0m"
	echo "IVDW = 21" >> INCAR
elif [ $n == 7 ] ; then
	echo -e "\e[33m                  Many-body dispersion energy method                        \e[0m"
	echo "IVDW = 202" >> INCAR
elif [ $n == 8 ] ; then
	echo -e "\e[33m                  dDsC dispersion correction method                         \e[0m"
	echo "IVDW = 4" >> INCAR
elif [ $n == 9 ] ; then
    echo -e "\e[33m*********************************************************************************\e[0m"
	echo -e "\e[33m*                            设置和安装DFT-D                                    *\e[0m"
stty erase ^h
stty erase ^?
stty erase ^H
read -p "Are you sure to install DFT-D?[ yes/no ] > " u 
#echo "$u was select"
if [ $u == yes ] || [ $u == y ] || [ $u == Y ] || [ $u == YES ] || [ $u == Yes ] ; then
    echo ""
        echo " DFT-D will be installed "
	echo " We will create a new folder, which path is /home/$USER/scripts. "
	echo " The DFT-D will saved in /home/$USER/scripts"
        now=$(pwd)
	#echo $(pwd)
	#echo $now
	#echo $USER
        cd /home/$USER 
        mkdir scripts
        cp $now/DFT-D.sh /home/$USER/scripts
	cd /home/$USER/scripts
	chmod +x DFT-D.sh
        cd
# 下边三行为测试程序，此处暂且保留
#	echo "####script的脚本【例如DFT-D】####" >> hanbin
#	echo "export PATH=/home/$USER/scripts:"'$PATH' >> hanbin
#	echo "alias DFT-D='DFT-D.sh'" >> hanbin
	#source $HOME/.bashrc
#接下来的程序会将DFT-D写入.bashrc
echo "####script的脚本【DFT-D】####" >> .bashrc
echo "export PATH=/home/$USER/scripts:"'$PATH' >> .bashrc
echo "alias DFTD='DFT-D.sh'" >> .bashrc
source $HOME/.bashrc
source .bashrc
#到此截止，请勿擅自修改，如果出现问题概不负责。

    echo ""
    echo -e "\e[33m*********************************************************************************\e[0m"
    echo -e "\e[33m*                 you have install it successfully!                             *\e[0m"
    echo -e "\e[33m*      You can run this program by typing DFTD in any suitable folder           *\e[0m"
elif [ $u == no ] || [ $u == n ] || [ $u == N ] || [ $u == NO ] || [ $u == No ]; then
	echo ""
  echo -e "\e[33m*********************************************************************************\e[0m"
  echo -e "\e[33m*             DFT-D have not been installed, the program will exit              *\e[0m"

else
	echo -e "\e[33m*********************************************************************************\e[0m"
	echo -e "\e[33m* 恭喜你发现了彩蛋！现在开始数5个数                                             *\e[0m"
	sleep 5
	echo -e "\e[33m* 于是你浪费了5秒                                                               *\e[0m "
fi
else
	echo " program exit "
fi
echo -e "\e[33m*********************************************************************************\e[0m"

#!/bin/bash
# eliminate forces of fixed atoms
fix=$1
if test -z $1; then
fix=0
fi
# get force form OUTCAR
awk -v fix="$fix" '/POSITION/,/drift/{
if($1~/^[0-9.]+$/&&$3>=fix) print $1,$2,$3,sqrt($4*$4+$5*$5+$6*$6i);
else if($1=="total") print $0
}' OUTCAR >temp.f
awk '{
if($1=="total") {print ++i,a;a=0}
else {if(a<$4) a=$4}
}' temp.f >force.log
tail -1000 force.log | cut -d ' ' -f 2-4 |  awk '{print log($0)}'>logforce.txt
# get energy
awk '/E0/{ print $5 }' OSZICAR >energy.txt
# plot energy
gnuplot <<EOF
set term dumb
set title 'Energy of each ion steps'
set xlabel 'Ion steps'
set ylabel 'Energy(eV)'
plot 'energy.txt'with line linetype 1 linewidth 1
EOF
#plot force
gnuplot <<EOF
set term dumb
set title 'Ln(Force) of each ion steps'
set xlabel 'Ion steps'
set ylabel 'Ln(Force) (eV/Angstrom)'
set yrange [-4.5:1.5]
plot 'logforce.txt'with line linetype 1 linewidth 1
EOF
rm temp.f logforce.txt energy.txt force.log

#!/bin/bash
bash $hvtpath/bin/Tools/split_dos > dos_split.dat
grep "Fermi level:" dos_split.dat > Fermi_Energy
echo "# Set the value of VBM if you want to shift VBM to zero eV." >> Fermi_Energy
rm -rf dos_split.dat

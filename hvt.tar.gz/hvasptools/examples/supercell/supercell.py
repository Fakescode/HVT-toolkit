from pymatgen.core import Lattice, Structure, Molecule

stru = input("""--> Select structure :  """)
a,b,c = input("""--> Transform unit along a, b, c with space (Must int,e.g., 1 2 2): """).split()

structure = Structure.from_file(stru)
structure.make_supercell(scaling_matrix=[a, b, c], to_unit_cell=False)
structure.to(fmt='POSCAR', filename='supercell.vasp')


## Get a primitive version of the Structure
#structure.get_primitive_structure()
#!/usr/bin/env python
# -*- coding: utf-8 -*-
# version:3.0
# 这个版本环境要求低
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
#------------------------------------------------------------------------------------#
print("--> Now reading vasp MD energies and temperature...")
f = open('OSZICAR','r')
w = open('AIMDout.dat','w')
lines = f.readlines()
for line in lines:
    if "T=" in line:
        row = line.split()
        x1 = row[0]   #获取第1列
        x3 = row[2]
        x9 = row[8]
        w.write(str(x1)+" "+str(x3)+" "+str(x9)+'\n')
print("--> Output: AIMDout.dat")  
#功能等于完整的grep T= OSZICAR|awk '{print $1"\t", $3, "\t" $9}' >AIMD.dat
#------------------------------------------------------------------------------------#
print("--> Start drawing...")
#数据
fn="AIMDout.dat"
file=open(fn,'r+')
lines=file.readlines()
x=[float(lines[i].strip().split()[0])for i in range(len(lines))]
y1=[float(lines[i].strip().split()[1])for i in range(len(lines))]
y2=[float(lines[i].strip().split()[2])for i in range(len(lines))]
#设置画布大小像素点
plt.figure(figsize=(14,14),dpi=300)
fs=26
fz=[8,4]
# 绘制图Temperature
plt.subplot(2,1,1)
xlab="Time steps"
ylab="Temperature (K)"
#plt.ylim(0,1200)
plt.plot(x,y1,label='Temperature(k)',color='black',linewidth=2)
plt.rcParams.update({'font.size': 24})  #标签的字体大小
plt.legend(loc='upper right')
plt.ylabel(ylab, fontsize = fs)
plt.xlabel(xlab, fontsize = fs)
plt.tick_params(labelsize=20)   #刻度值字体大小
#plt.gca().yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f')) #y坐标轴刻度保留两位小数
# 绘制图energy
plt.subplot(2,1,2)
xlab="Time steps"
ylab="Energy (eV)"
plt.plot(x,y2,label='Energy(eV)',color='black',linewidth=2)
plt.rcParams.update({'font.size': 24})
plt.legend(loc='upper right')
plt.ylabel(ylab, fontsize = fs)
plt.xlabel(xlab, fontsize = fs)
plt.tick_params(labelsize=20)
#plt.gca().yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
plt.savefig("AIMDplot.png")
plt.show()
print("--> Output: Temperature.png & Energy.png")

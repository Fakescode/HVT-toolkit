#!/usr/bin/env python
# -*- coding: utf-8 -*-
# version:3.0
# author: Hanbin
# Make sure you have installed python3, numpy, scipy, matplotlib, etc.
# If the drawing fails, check your running environment. 
# This script can be used to plot images of temperature and energy over time during AIMD calculations. 
print("""--> Scripts used to process vasp AIMD""")
import matplotlib.pyplot as plt
#------------------------------------------------------------------------------------#
print("--> Now reading vasp MD energies and temperature...")
f = open('OSZICAR','r')
w = open('AIMDout.dat','w')
lines = f.readlines()
for line in lines:
    if "T=" in line:
        row = line.split()
        x1 = row[0]   #获取第1列
        x3 = row[2]
        x9 = row[8]
        w.write(str(x1)+" "+str(x3)+" "+str(x9)+'\n')
print("--> Output: AIMDout.dat")  
#功能等于完整的grep T= OSZICAR|awk '{print $1"\t", $3, "\t" $9}' >AIMD.dat
#------------------------------------------------------------------------------------#
print("--> Start drawing...")
#数据
fn="AIMDout.dat"
file=open(fn,'r+')
lines=file.readlines()
x=[float(lines[i].strip().split()[0])for i in range(len(lines))]
y1=[float(lines[i].strip().split()[1])for i in range(len(lines))]
y2=[float(lines[i].strip().split()[2])for i in range(len(lines))]
fs=16   #字体大小
xlab1="Time steps (fs)"
xlab2="Time steps (fs)"
ylab1="Temperature (K)"
ylab2="Energy (eV)"
# 绘制图Temperature
fig,ax = plt.subplots(2,1,figsize=(8,8),facecolor='w')
#ax[0].set_ylim(0,1200) #限制某个坐标轴的范围
ax[0].plot(x,y1,label='Temperature(k)',color='black')
plt.rcParams.update({'font.size': 14})
ax[0].legend(loc='upper right')
ax[0].set_ylabel(ylab1, fontsize = fs)
ax[0].set_xlabel(xlab1, fontsize = fs)
# 绘制图Energy
ax[1].plot(x,y2,label='Energy(eV)',color='black')
plt.rcParams.update({'font.size': 14})
ax[1].legend(loc='upper right')
ax[1].set_ylabel(ylab2, fontsize = fs)
ax[1].set_xlabel(xlab2, fontsize = fs)
plt.savefig('AIMD.png',dpi=500)
print("--> Output: Temperature.png & Energy.png")
